package com.cg.dw.controller;

import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dw.exception.IBSException;
import com.cg.dw.service.DepartmentService;

@Controller
public class CardController {
	@Autowired
	private DepartmentService deptService;

	@RequestMapping("/cards")
	public ModelAndView showCardHome() {
		return new ModelAndView("cardsHomePage", "depts", deptService.findAll());
	}

	@RequestMapping("/cardMenu")
	public String showDeptsMenu() {
		return "cardsMenuPage";
	}

	@RequestMapping(value = "/block", method = RequestMethod.GET)
	public String BlockCard() {
		return "wantBlockPage";
	}

	@RequestMapping(value = "/block", method = RequestMethod.POST)
	public ModelAndView block(@RequestParam("debitCard") BigInteger debitCard) {
		String output = "Default";
		if (deptService.requestDebitCardLost(debitCard)) {
			output = "Done";
		} else {
			output = "Not Done";
		}
		return new ModelAndView("BlockedDeptPage", "output", output);
	}

	@RequestMapping(value = "/upgrade", method = RequestMethod.GET)
	public String UpgradeCard() {
		return "wantUpgradePage";
	}

	@RequestMapping(value = "/upgrade", method = RequestMethod.POST)
	public ModelAndView upgrade(@RequestParam("debitCard") BigInteger debitCard, @RequestParam String myChoice,
			@RequestParam String remarks) {
		String output = null;
		ModelAndView mv = new ModelAndView();
		try {
			output = deptService.requestDebitCardUpgrade(debitCard, myChoice, remarks);
			mv.setViewName("UpgradePage");

		} catch (IBSException e) {
			output = e.getMessage();
			mv.setViewName("ErrorPage");

		}
		mv.addObject(output);
		return mv;
	}

}

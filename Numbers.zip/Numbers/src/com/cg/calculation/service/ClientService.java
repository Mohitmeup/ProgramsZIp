package com.cg.calculation.service;

public class ClientService {

	public double[] fibonacciSeries(int n) {
		double[] fibS = new double[n]; //creating new double array
		int i;
		fibS[0] = 0.00;
		fibS[1] = 1.00;
		for (i = 2; i < n; i++) {
			fibS[i] = fibS[i - 1] + fibS[i - 2];
		}
		return fibS; 
	}
}

package com.cg.JPADEMO.service;

import java.util.List;

import javax.persistence.EntityTransaction;

import com.cg.JPADEMO.dao.BookDao;
import com.cg.JPADEMO.dao.BookDaoImpl;
import com.cg.JPADEMO.model.Book;
import com.cg.JPADEMO.util.JPAUtil;

public class BookServiceImpl implements BookService{

	private BookDao bookDao;
	
	public BookServiceImpl() {
		bookDao=new BookDaoImpl();
	}
	
	public Book addBook(Book book) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		Book savedBook=bookDao.addBook(book);
		txn.commit();
		return savedBook;
	}

	public Book updateBook(Book book) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		Book savedBook=bookDao.updateBook(book);
		txn.commit();
		return savedBook;
	}

	public Book getBookByBcode(Integer bcode) {
		return bookDao.getBookByBcode(bcode);
	}

	public List<Book> getAllBooks() {
		return bookDao.getAllBooks();
	}

	public boolean removeBook(Integer bcode) {
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		boolean isDeleted = bookDao.removeBook(bcode);
		txn.commit();
		return isDeleted;
	}

}

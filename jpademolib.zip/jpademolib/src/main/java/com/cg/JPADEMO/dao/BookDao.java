package com.cg.JPADEMO.dao;

import java.util.List;

import com.cg.JPADEMO.model.Book;

public interface BookDao {

	Book addBook(Book book);
	Book updateBook(Book book);
	Book getBookByBcode(Integer bcode);
	List<Book> getAllBooks();
	boolean removeBook(Integer bcode);

}

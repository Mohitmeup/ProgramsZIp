package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.BowBean;
import com.cg.service.CalcService;

@Controller
@RequestMapping("/")
public class CalcController {

	@Autowired
	private CalcService calcService;

	@RequestMapping(method = RequestMethod.GET, value="add")
	public ModelAndView sum(@RequestParam("num1") int num1, @RequestParam("num2") int num2) {
		BowBean bean = new BowBean();
		bean.setNum1(num1);
		bean.setNum2(num2);
		int result = calcService.sum(bean);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("result" , result);
		modelAndView.setViewName("showMessage");
		return modelAndView;
	}
}

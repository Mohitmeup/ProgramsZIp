package com.cg.service;

import org.springframework.stereotype.Service;
import com.cg.model.BowBean;

@Service
public class CalcServiceImpl implements CalcService {

	public int sum(BowBean bean) {
		int result = bean.getNum1() + bean.getNum2(); 
		return result;
	}

}

package com.cg.service;

import com.cg.model.BowBean;

public interface CalcService {
	public int sum(BowBean bean);
}

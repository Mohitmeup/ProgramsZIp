package com.cg.st.service;

public interface GreetService {
	String greet(String username);

}

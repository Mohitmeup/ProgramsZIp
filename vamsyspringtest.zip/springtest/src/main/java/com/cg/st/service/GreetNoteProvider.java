package com.cg.st.service;

public interface GreetNoteProvider {
	String getGreetNote();

}

package com.cg.st.service;

public class SimpleGreetServiceImpl implements GreetService {

	public String greet(String username) {
		return "Hello " + username;
	}

	
}

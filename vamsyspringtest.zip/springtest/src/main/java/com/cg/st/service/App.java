package com.cg.st.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
//		SimpleGreetServiceImpl gs = new SimpleGreetServiceImpl();
		ApplicationContext gtc = new ClassPathXmlApplicationContext("myBeans.xml");
		GreetService gs = (GreetService) gtc.getBean("ags");
		System.out.println(gs.greet("Divye"));
	}

}

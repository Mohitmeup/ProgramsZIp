package com.cg.bankdetails.dao;

import com.cg.bankdetails.bean.Account;

public class BankDao {

	private Account[] details = new Account[5];

	public Account[] getDetails() {
		return details;
	}

	public void setDetails(Account[] details) {
		this.details = details;
	}
	public void saveDetails (Account account, int num){
		details[num] = account;
	}
			
	
	
	
	
	
	
	
}

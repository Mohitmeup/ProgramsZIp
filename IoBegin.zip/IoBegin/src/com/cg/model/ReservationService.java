package com.cg.model;

import java.util.ArrayList;

//import javax.swing.event.TreeWillExpandListener;

public class ReservationService implements Runnable {
	private Bus bus;
	private java.util.List<Integer> seatsAlloted;
	private synchronized void reserve() {
		seatsAlloted = new ArrayList<>();
		for(int i=1; i<=requiredSeats; i++) {
			if(bus.getLastReservedSeat()==bus.getSeatCount()) {
				break;
			}
			else {
				int seat = bus.getLastReservedSeat()+1;
				bus.setLastReservedSeat(seat);
				seatsAlloted.add(seat);
			}
		}
	}
	public ReservationService(Bus bus, int requiredSeats) {
		super();
		this.bus = bus;
		this.requiredSeats = requiredSeats;
	}
	private int requiredSeats;
	@Override
	public void run() {	
		Thread t = Thread.currentThread();
		if(bus.getSeatCount()-bus.getLastReservedSeat() >= requiredSeats) {
			reserve();
			
			System.out.println(t.getName()+" : "+seatsAlloted);
		}
		else {
			System.out.println("Sorry. Not enough seats");
		}
		
	}

}
package com.cg.iobegin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.Buffer;

public class IoByte {
	public static void main(String[] args) throws IOException {

		File file = new File("C://Users//MOPURSNA//Desktop//abc.txt");
		FileInputStream inputStream = new FileInputStream(file);
		int ch;
		StringBuffer sb = new StringBuffer();
		while ((ch = inputStream.read()) != (-1)) {
			sb.append((char) ch);
		}
		System.out.println(sb);
		inputStream.close();
		sb.reverse();
		File file2 = new File("C://Users//MOPURSNA//Desktop//abc1.txt");
		FileOutputStream outputStream = new FileOutputStream(file2);
		outputStream.write(sb.toString().getBytes());
		outputStream.close();
		
	}
}

package com.cg.iobegin;

public class Multirhreading {
	public static void main(String[] args) {
		Thread thread = Thread.currentThread();
		System.out.println(thread.getName());
	}
}

package com.cg.iobegin;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class Buffer {
	public static void main(String[] args) throws IOException {
		FileInputStream inputStream = new FileInputStream("C://Users//MOPURSNA//Desktop//abc.txt");
		BufferedInputStream inputStream2 = new BufferedInputStream(inputStream);
		int ch;
		inputStream.`
		StringBuffer sb = new StringBuffer();
		while ((ch = inputStream.read()) != (-1)) {
			sb.append((char) ch);
		}
		inputStream2.close();
		inputStream.close();
		System.out.println(sb);

	}
	}


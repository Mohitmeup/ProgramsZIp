package com.cg.iobegin;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class IoChar {
	public static void main(String[] args) throws IOException {
		String str = " Hjkimm;gm;g \n" + "yesss hahahahaglobalgear\n";
		FileWriter fileWriter = new FileWriter("C://Users//MOPURSNA//Desktop//write.txt");
		fileWriter.
		//fileWriter.write(str);
		fileWriter.close();
		
		FileReader fileReader = new FileReader("C://Users//MOPURSNA//Desktop//write.txt");
		int ch;
		while((ch = fileReader.read())!= -1){
			System.out.print((char)ch);		
		}fileReader.close();
	}
}
;
package com.cg.datetime;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateTime {

	public static void main(String[] args) {
		/* System.out.println(LocalDate.now()); 
		 * LocalDate today = LocalDate.now(); LocalDate independence =
		 * LocalDate.of(1947, Month.AUGUST, 15); Period p =
		 * Period.between(today, independence); System.out.println(p); Duration
		 * d = Duration.ofDays(days); System.out.println(d); LocalDate target =
		 * today.plusYears(10); LocalDate target2 = today.minusYears(10);
		 * System.out.println(target); System.out.println(target2);
		 * 
		 * DateTimeFormatter dtformat =
		 * DateTimeFormatter.ofPattern("MMM dd,yyyy");
		 * System.out.println(today.format(dtformat));
		 * 
		 * //HAVE TO TAKE Local Time LocalDateTime today1= LocalDateTime.now();
		 * DateTimeFormatter dtFormat1=
		 * DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm:ss a");
		 * System.out.println(today1.format(dtFormat1));
		 * 
		 * String s = "Oct 02 1901"; DateTimeFormatter dtformat2 =
		 * DateTimeFormatter.ofPattern("MMM dd yyyy"); LocalDate dt =
		 * LocalDate.parse(s, dtformat2); System.out.println(dt);
		 * 
		 * LocalDate today = LocalDate.now(); Scanner scanner = new
		 * Scanner(System.in);
		 * System.out.println("Enter the date of birth in the format dd-MM-yyyy"
		 * ); DateTimeFormatter dtformat3 =
		 * DateTimeFormatter.ofPattern("dd-MM-yyyy"); String s = scanner.next();
		 * LocalDate dt3 = LocalDate.parse(s, dtformat3); Period p =
		 * Period.between(dt3, today); System.out.println(p);
		 * System.out.println(dt3);
		 */
		String s = "24568";
		Pattern pattern = Pattern.compile(s);
		Matcher matcher = pattern.matcher(s);
		System.out.println();
	}
}

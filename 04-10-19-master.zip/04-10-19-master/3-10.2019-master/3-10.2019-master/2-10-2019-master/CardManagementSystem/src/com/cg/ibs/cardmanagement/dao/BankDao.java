package com.cg.ibs.cardmanagement.dao;

import com.cg.ibs.cardmanagement.cardbean.CaseIdBean;

public interface BankDao {
	
 

 void viewAllQueries(CaseIdBean caseIdObj);
	  
  
	
	
	
}

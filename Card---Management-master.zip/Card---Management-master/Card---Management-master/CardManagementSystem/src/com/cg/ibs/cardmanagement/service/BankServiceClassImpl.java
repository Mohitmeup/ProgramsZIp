package com.cg.ibs.cardmanagement.service;

public class BankServiceClassImpl {

}

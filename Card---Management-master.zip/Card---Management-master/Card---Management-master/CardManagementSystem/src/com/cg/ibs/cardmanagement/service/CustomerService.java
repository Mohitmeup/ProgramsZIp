package com.cg.ibs.cardmanagement.service;

public interface CustomerService {

}

package com.cg.practice;

public class JDBC {
	public Set<CreditCard> getDetails(String uci) throws IBSExceptions {
        Set<CreditCard> getCreditCards = new HashSet<>();
        Connection connection= ConnectionUtil.getConnection();
            try(PreparedStatement preparedStatement = connection.prepareStatement(QueryMap.getCreditCardDetails);){
                preparedStatement.setBigDecimal(1, new BigDecimal(uci));
                try (ResultSet resultSet = preparedStatement.executeQuery();){
                    while(resultSet.next()) {
                        getCreditCards.add(new CreditCard(new BigInteger(resultSet.getBigDecimal("credit_card_num").toString()), 
                        resultSet.getString("name_on_cred_card"), resultSet.getDate("credit_expiry_date").toString()));
                    }
                }
            }catch(SQLException exception) {
                    throw new IBSExceptions(ExceptionMessages.ERROR11);
            }
            return getCreditCards;
    }

 

    public boolean copyDetails(String uci, String response, CreditCard card) throws IBSExceptions{
        boolean result = false;
        
        if (card != null) {
            Connection connection = ConnectionUtil.getConnection();
            try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMap.insertCreditCard);                ){
                preparedStatement.setBigDecimal(1, new BigDecimal(card.getcreditCardNumber()));
                preparedStatement.setBigDecimal(2, new BigDecimal(uci));
                preparedStatement.setString(3, card.getcreditDateOfExpiry());
                preparedStatement.setString(4, card.getnameOnCreditCard());
                preparedStatement.setString(5, response);
                LocalDateTime dateTime = LocalDateTime.now();
                preparedStatement.setTimestamp(6, Timestamp.valueOf(dateTime));
                int check = preparedStatement.executeUpdate();
                if(check>0)
                {
                    result = true;
                }
            }catch(SQLException exception)
            {
                throw new IBSExceptions(ExceptionMessages.ERROR11);
            }
        }
      return result;
    }
}

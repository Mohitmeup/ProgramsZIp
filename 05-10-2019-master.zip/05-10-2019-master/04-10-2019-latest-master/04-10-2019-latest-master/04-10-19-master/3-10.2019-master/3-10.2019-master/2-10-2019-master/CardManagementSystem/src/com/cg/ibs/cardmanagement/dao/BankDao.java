package com.cg.ibs.cardmanagement.dao;

import java.util.List;

import com.cg.ibs.cardmanagement.cardbean.CaseIdBean;

public interface BankDao {
	
 

List<CaseIdBean > viewAllQueries();
	  
  
	
	
	
}

package com.cg.ibs.cardmanagement.service;

import java.util.List;

import com.cg.ibs.cardmanagement.cardbean.CaseIdBean;
import com.cg.ibs.cardmanagement.cardbean.DebitCardBean;

public interface BankService   {


	
	 public List<CaseIdBean> viewQueries() ;
	
	
}

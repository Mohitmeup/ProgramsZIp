
public class Z {
public static void main(String[] args) {
	System.out.println(new Z().helloName("ajay"));
}
public String helloName(String name) {
	  char f=name.toUpperCase().charAt(0);
	  String s=name.substring(1);
	  return "Hello "+f+s+"!";
	}
}

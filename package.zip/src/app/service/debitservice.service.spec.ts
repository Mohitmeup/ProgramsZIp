import { TestBed } from '@angular/core/testing';

import { DebitserviceService } from './debitservice.service';

describe('DebitserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DebitserviceService = TestBed.get(DebitserviceService);
    expect(service).toBeTruthy();
  });
});

import { Component} from '@angular/core';
import { Debitmodel } from '../model/debitmodel';
import { DebitserviceService } from '../service/debitservice.service';
import { Router } from '@angular/router';
import { SweetAlertService } from 'angular-sweetalert-service';

@Component({
  selector: 'app-debitlist',
  templateUrl: './debitlist.component.html',
  styleUrls: ['./debitlist.component.css']
})
export class DebitlistComponent {

  bean: Debitmodel[];
  bean1: Debitmodel;
  constructor(private debitService: DebitserviceService, private router:Router,private alertService: SweetAlertService) {
  }

  load() {
    console.log("enter1");
    this.debitService.getAll().subscribe(
      (data) => {
        console.log("enter");
        this.bean = data;
     
    }
      );
}

details(g : Debitmodel){
  this.alertService.confirm({
    title: 'Delete account?'})
  .then(() => {
    this.alertService.success({
      title: 'Account deleted'});
  })
  .catch(() => console.log('canceled'));
  this.debitService.getDetails(g.cardNumber).subscribe(
    (data) => {
      this.bean1 = data;
    }
  )
}

route(){
  this.router.navigateByUrl("contact/debitlist/block1");
}
}
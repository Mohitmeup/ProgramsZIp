package com.cg.ibs.cardmanagement.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.CustomerBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CardManagementDaoImpl implements CustomerDao, BankDao {

	CaseIdBean caseIdObj = new CaseIdBean();
	DebitCardBean bean = new DebitCardBean();
	CreditCardBean bean1 = new CreditCardBean();
	CustomerBean bean2 = new CustomerBean();
	AccountBean bean3 = new AccountBean();

	public CardManagementDaoImpl() {
		super();
	}

	public CardManagementDaoImpl(CaseIdBean caseIdObj) {
		super();

		this.caseIdObj = caseIdObj;

	}





	@Override
	public List<DebitCardBean> viewAllDebitCards() {
		String sql = SqlQueries.SELECT_DATA_FROM_DEBIT_CARD;
		List<DebitCardBean> debitCards = new ArrayList();
		try (Connection connection = ConnectionProvider.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {

					DebitCardBean deb = new DebitCardBean();
					BigInteger debitCardNumber = resultSet.getBigDecimal("debit_card_number").toBigInteger();
					// String status=resultSet.getString("debit_card_status");
					String name = resultSet.getString("name_on_deb_card");
					int cvv = resultSet.getInt("debit_cvv_num");
					LocalDate dateOfExpiry = resultSet.getDate("debit_expiry_date").toLocalDate();
					String debitCardType = resultSet.getString("debit_card_type");
					deb.setDebitCardNumber(debitCardNumber);
					deb.setNameOnDebitCard(name);
					deb.setDebitCvvNum(cvv);
					deb.setDebitDateOfExpiry(dateOfExpiry);
					deb.setDebitCardType(debitCardType);

					debitCards.add(deb);

				}

			} catch (Exception e) {
				System.out.println(e.getMessage());

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return debitCards;

	}

	public List<CreditCardBean> viewAllCreditCards() {
		String sql = SqlQueries.SELECT_DATA_FROM_CREDIT_CARD;
		List<CreditCardBean> creditCards = new ArrayList();
		try (Connection connection = ConnectionProvider.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {

					CreditCardBean crd = new CreditCardBean();
					BigInteger creditCardNumber = resultSet.getBigDecimal("credit_card_num").toBigInteger();
					String status = resultSet.getString("credit_card_status");
					String name = resultSet.getString("name_on_cred_card");
					int cvv = resultSet.getInt("credit_cvv_num");
					LocalDate dateOfExpiry = resultSet.getDate("credit_expiry_date").toLocalDate();
					String creditCardType = resultSet.getString("credit_card_type");
					crd.setCreditCardNumber(creditCardNumber);
					crd.setCreditCardStatus(status);
					crd.setNameOnCreditCard(name);
					crd.setCreditCvvNum(cvv);
					crd.setCreditDateOfExpiry(dateOfExpiry);
					crd.setCreditCardType(creditCardType);

					creditCards.add(crd);

				}

			} catch (Exception e) {
				System.out.println(e.getMessage());

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return creditCards;

	}

	

	public int requestDebitCardUpgrade(CaseIdBean caseIdObj, BigInteger debitCardNumber) {

		String sql = SqlQueries.REQUEST_DEBIT_CARD_CARD;

		try (Connection connection = ConnectionProvider.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

			preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
			preparedStatement.setDate(2, java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));
			preparedStatement.setString(3, caseIdObj.getStatusOfQuery());
			preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getAccountNumber()));
			preparedStatement.setBigDecimal(5, new BigDecimal(caseIdObj.getUCI()));
			preparedStatement.setString(6, caseIdObj.getDefineQuery());
			preparedStatement.setBigDecimal(7, new BigDecimal(debitCardNumber));
			preparedStatement.setString(8, caseIdObj.getCustomerReferenceId());
			int result = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			System.out.println(e.getMessage());

		}
		return result;

	}
	

	

	@Override
	public List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) {
		/*
		 * LocalDateTime dLocalDateTime = LocalDateTime.now().minusDays(days); // String
		 * sql = SqlQueries.SELECT_DATA_FROM_DEBIT_TRANSACTION;
		 * List<CreditCardTransaction> creditCardsList = new ArrayList(); try
		 * (Connection connection = ConnectionProvider.getInstance().getConnection();
		 * PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
		 * 
		 * try (ResultSet resultSet = preparedStatement.executeQuery()) {
		 * 
		 * while (resultSet.next()) {
		 * 
		 * DebitCardBean deb = new DebitCardBean(); BigInteger debitCardNumber =
		 * resultSet.getBigDecimal("debit_card_number").toBigInteger(); // String
		 * status=resultSet.getString("debit_card_status"); String name =
		 * resultSet.getString("name_on_deb_card"); int cvv =
		 * resultSet.getInt("debit_cvv_num"); LocalDate dateOfExpiry =
		 * resultSet.getDate("debit_expiry_date").toLocalDate(); String debitCardType =
		 * resultSet.getString("debit_card_type");
		 * deb.setDebitCardNumber(debitCardNumber); deb.setNameOnDebitCard(name);
		 * deb.setDebitCvvNum(cvv); deb.setDebitDateOfExpiry(dateOfExpiry);
		 * deb.setDebitCardType(debitCardType);
		 * 
		 * // debitCards.add(deb);
		 * 
		 * }
		 * 
		 * } catch (Exception e) { System.out.println(e.getMessage());
		 * 
		 * } } catch (Exception e) { e.printStackTrace(); }
		 * 
		 * 
		 */

		return null;
	}

	@Override
	public List<CaseIdBean> viewAllQueries() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean verifyQueryId(String queryId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setQueryStatus(String queryId, String newStatus) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionANDC(BigInteger debitCardNumber, Integer cvv, Integer pin, String queryId, String status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionANCC(BigInteger creditCardNumber, int cvv, int pin, String queryId, int score, double income,
			String status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionBlockDC(String queryId, String status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionBlockCC(String queryId, String status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionUpgradeDC(String queryId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionUpgradeCC(String queryId) throws IBSException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void newDebitCard(CaseIdBean caseIdObj, BigInteger accountNumber) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void newCreditCard(CaseIdBean caseIdObjId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public BigInteger getAccountNumber(BigInteger debitCardNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getdebitCardType(BigInteger debitCardNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void requestDebitCardLost(CaseIdBean caseIdObj, BigInteger debitCardNumber) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void requestCreditCardLost(CaseIdBean caseIdObj, BigInteger creditCardNumber) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean verifyAccountNumber(BigInteger accountNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean verifyDebitCardNumber(BigInteger debitCardNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean verifyCreditCardNumber(BigInteger creditCardNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setNewDebitPin(BigInteger debitCardNumber, int newPin) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getDebitCardPin(BigInteger debitCardNumber) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setNewCreditPin(BigInteger creditCardNumber, int newPin) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getCreditCardPin(BigInteger creditCardNumber) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public BigInteger getUci() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigInteger getDebitUci(BigInteger debitCardNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigInteger getCreditUci(BigInteger creditCardNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getcreditCardType(BigInteger creditCardNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean verifyCreditTransactionId(String transactionId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void raiseDebitMismatchTicket(CaseIdBean caseIdObj, String transactionId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void raiseCreditMismatchTicket(CaseIdBean caseIdObj, String transactionId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<DebitCardTransaction> getDebitTrans(int dys, BigInteger debitCardNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void requestCreditCardUpgrade(CaseIdBean caseIdObj, BigInteger creditCardNumber) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean verifyDebitTransactionId(String transactionId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getCustomerReferenceId(CaseIdBean caseIdObj, String customerReferenceId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDebitCardStatus(BigInteger debitCardNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCreditCardStatus(BigInteger creditCardNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigInteger getDebitCardNumber(String transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigInteger getDMUci(String transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigInteger getDMAccountNumber(String transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigInteger getCMUci(String transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigInteger getNDCUci(BigInteger accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}}








	
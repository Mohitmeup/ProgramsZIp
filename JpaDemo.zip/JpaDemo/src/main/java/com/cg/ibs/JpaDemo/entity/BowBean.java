package com.cg.ibs.JpaDemo.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table (name = "BowTable")
public class BowBean implements Serializable{
@Id
	private int bowId;
@Column(name = "Name")
private String bowName;
private String bowDescription;
public int getBowId() {
	return bowId;
}
public void setBowId(int bowId) {
	this.bowId = bowId;
}
public String getBowName() {
	return bowName;
}
public void setBowName(String bowName) {
	this.bowName = bowName;
}
public String getBowDescription() {
	return bowDescription;
}
public void setBowDescription(String bowDescription) {
	this.bowDescription = bowDescription;
}



}

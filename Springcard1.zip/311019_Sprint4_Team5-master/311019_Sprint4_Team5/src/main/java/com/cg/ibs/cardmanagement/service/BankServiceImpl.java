package com.cg.ibs.cardmanagement.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.CustomerBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.dao.CaseIdDao;
import com.cg.ibs.cardmanagement.dao.CreditCardDao;
import com.cg.ibs.cardmanagement.dao.CreditCardTransactionDao;
import com.cg.ibs.cardmanagement.dao.CustomerDao;
import com.cg.ibs.cardmanagement.dao.DebitCardDao;
import com.cg.ibs.cardmanagement.dao.DebitCardTransactionDao;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

@Service
public class BankServiceImpl implements BankService {
	private static Logger logger = Logger.getLogger(BankServiceImpl.class);
	@Autowired
	private CaseIdDao caseIdDao;
	@Autowired
	private DebitCardTransactionDao debitCardTransactionDao;
	@Autowired
	private CreditCardTransactionDao creditCardTransactionDao;
	@Autowired
	private DebitCardDao debitCardDao;
	@Autowired
	private CreditCardDao creditCardDao;
	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private DebitCardBean bean;
	@Autowired
	private CreditCardBean bean1;
	Random random = new Random();

	@Override
	public List<CaseIdBean> viewQueries() throws IBSException {
		logger.info("entered into viewQueries method of BankServiceImpl class");

		try {
			return caseIdDao.viewAllQueries();
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}

	}

	public List<DebitCardTransaction> getDebitTransactions(int dys, BigInteger debitCardNumber) throws IBSException {
		logger.info("entered into getDebitTransactions method of BankServiceImpl class");
		List<DebitCardTransaction> debitCardBeanTrns = debitCardTransactionDao.getDebitTrans(dys, debitCardNumber);
		if (debitCardBeanTrns.isEmpty())
			throw new IBSException("NO TRANSACTIONS");
		return debitCardTransactionDao.getDebitTrans(dys, debitCardNumber);
	}

	@Override
	public boolean verifyQueryId(String queryId) throws IBSException {
		logger.info("entered into verifyQueryId method of CreditCardDaoImpl class");

		boolean check = caseIdDao.verifyQueryId(queryId);
		if (check) {
			return true;
		} else {

			throw new IBSException("Invalid Query Id");
		}
	}

	public boolean verifyDebitCardNumber(BigInteger debitCardNumber) throws IBSException {
		logger.info("entered into verifyDebitCardNumber method of BankServiceImpl class");
		String debitCardNum = debitCardNumber.toString();
		Pattern pattern = Pattern.compile("[0-9]{16}");
		Matcher matcher = pattern.matcher(debitCardNum);
		if (!(matcher.find() && matcher.group().equals(debitCardNum)))
			throw new IBSException("Incorrect  length");
		boolean check = debitCardDao.verifyDebitCardNumber(debitCardNumber);
		if (!check)
			throw new IBSException(" Debit Card Number does not exist");
		return (check);

	}

	public boolean verifyCreditCardNumber(BigInteger creditCardNumber) throws IBSException {
		logger.info("entered into verifyCreditCardNumber method of BankServiceImpl class");
		String creditCardNum = creditCardNumber.toString();
		Pattern pattern = Pattern.compile("[0-9]{16}");
		Matcher matcher = pattern.matcher(creditCardNum);
		if (!(matcher.find() && matcher.group().equals(creditCardNum)))
			throw new IBSException("Incorrect  length");
		boolean check1 = creditCardDao.verifyCreditCardNumber(creditCardNumber);
		if (!check1)
			throw new IBSException(" Credit Card Number does not exist");
		return (check1);
	}

	@Override
	public List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) throws IBSException {
		logger.info("entered into getCreditTrans method of BankServiceImpl class");
		List<CreditCardTransaction> creditCardBeanTrns = creditCardTransactionDao.getCreditTrans(days,
				creditCardNumber);
		if (creditCardBeanTrns.isEmpty())
			throw new IBSException("NO TRANSACTIONS");
		return creditCardTransactionDao.getCreditTrans(days, creditCardNumber);

	}

	public String getNewQueryStatus(int newQueryStatus) throws IBSException {
		logger.info("entered into getNewQueryStatus method of BankServiceImpl class");
		String queryStatus = newQueryStatus + "";
		Pattern pattern = Pattern.compile("[123]");
		Matcher matcher = pattern.matcher(queryStatus);
		if (!(matcher.find() && matcher.group().equals(queryStatus)))
			throw new IBSException("Not a valid input");

		switch (newQueryStatus) {
		case 1:

			queryStatus = "Approved";
			break;
		case 2:
			queryStatus = "In Process";
			break;
		case 3:
			queryStatus = "Disapproved";
			break;
		default:
			queryStatus = "Pending";
			break;

		}
		return queryStatus;
	}

	public void checkDays(int days1) throws IBSException {
		logger.info("entered into checkDays method of BankServiceImpl class");
		if (days1 < 1) {

			throw new IBSException("Statement can not be generated for less than 1 day");

		} else if (days1 >= 730) {

			throw new IBSException("Enter days less than 730");
		}

	}

	@Override
	public void setQueryStatus(String queryId, String newStatus) throws IBSException {
		logger.info("entered into setQueryStatus method of BankServiceImpl class");
		try {
			caseIdDao.setQueryStatus(queryId, newStatus);
			if (newStatus.contains("Approved")) {
				if (queryId.contains("ANDC")) {
					getNewDC(queryId);
				} else if (queryId.contains("ANCC")) {
					getNewCC(queryId);
				}

				else if (queryId.contains("RDCU")) {

					upgradeDC(queryId);
				} else if (queryId.contains("RCCU")) {
					upgradeCC(queryId);
				}

			}
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}
	}

	@Override
	public void upgradeCC(String queryId) throws IBSException {
		logger.info("entered into upgradeCC method of BankServiceImpl class");
		try {
			creditCardDao.actionUpgradeCC(queryId);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}
	}

	private void upgradeDC(String queryId) throws IBSException {
		logger.info("entered into upgradeDC method of BankServiceImpl class");
		try {
			debitCardDao.actionUpgradeDC(queryId);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}

	}

	private void getNewCC(String queryId) throws IBSException {
		logger.info("entered into getNewCC method of BankServiceImpl class");

		try {
			CaseIdBean obj = caseIdDao.getCaseObj(queryId);

			CustomerBean customBean = new CustomerBean();
			customBean.setUCI((obj.getUCI()));
			bean1.setCustBeanObject(customBean);
			bean1.setNameOnCard(customerDao.getNewName(caseIdDao.getNewUCI(queryId)));
			String cvv = String.format("%03d", random.nextInt(1000));
			bean1.setCvvNum(cvv);
			String pin = String.format("%04d", random.nextInt(10000));
			bean1.setCurrentPin(pin);
			Long first14 = (long) (Math.random() * 100000000000000L);
			Long number = 5200000000000000L + first14;
			BigInteger creditCardNumber = BigInteger.valueOf(number);
			bean1.setCardNumber(creditCardNumber);
			String scoreString = String.format("%04d", random.nextInt(1000));
			int score = Integer.parseInt(scoreString);
			bean1.setCreditScore(score);
			String incomeString = String.format("%04d", random.nextInt(100000));
			double income = Integer.parseInt(incomeString);
			bean1.setIncome(income);
			String status = "Active";
			bean1.setCardStatus(status);
			LocalDate expiry = LocalDate.now().plusYears(5);
			bean1.setDateOfExpiry(expiry);
			String type = caseIdDao.getNewType(queryId);
			if (type.equals("Platinum")) {
				bean1.setCardType("Platinum");
				bean1.setCreditLimit(new BigDecimal(500000));
			} else if (type.equals("Gold")) {
				bean1.setCardType("Gold");
				bean1.setCreditLimit(new BigDecimal(100000));
			} else if (type.equals("Silver")) {
				bean1.setCardType("Silver");
				bean1.setCreditLimit(new BigDecimal(50000));
			}

			creditCardDao.actionANCC(bean1);

		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}

	}

	@Override
	public void getNewDC(String queryId) throws IBSException {
		logger.info("entered into getNewDC method of BankServiceImpl class");

		try {
			BigInteger uci = caseIdDao.getNewUCI(queryId);
			String Name = customerDao.getNewName(uci);
			bean.setNameOnCard(Name);
			bean.setCvvNum(String.format("%03d", random.nextInt(1000)));
			CaseIdBean obj = caseIdDao.getCaseObj(queryId);

			AccountBean accountBean = new AccountBean();
			accountBean.setAccountNumber(obj.getAccountNumber());
			System.out.println("bank" + accountBean.getAccountNumber());
			bean.setAccountBeanObject(accountBean);
			bean.setCurrentPin(String.format("%04d", random.nextInt(10000)));
			Long first14 = (long) (Math.random() * 100000000000000L);
			Long number = 5200000000000000L + first14;
			BigInteger debitCardNumber = BigInteger.valueOf(number);
			bean.setCardNumber(debitCardNumber);
			String status = "Active";
			bean.setCardStatus(status);
			LocalDate expiry = LocalDate.now().plusYears(5);
			bean.setDateOfExpiry(expiry);
			String type = caseIdDao.getNewType(queryId);
			System.out.println(queryId);
			if (type.equals("Platinum")) {
				bean.setCardType("Platinum");
			} else if (type.equals("Gold")) {
				bean.setCardType("Gold");
			} else if (type.equals("Silver")) {
				bean.setCardType("Silver");
			}
			debitCardDao.actionANDC(bean);

		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}

	}

}
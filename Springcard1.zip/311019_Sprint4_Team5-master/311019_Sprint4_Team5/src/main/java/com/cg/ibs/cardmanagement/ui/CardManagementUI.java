package com.cg.ibs.cardmanagement.ui;

import java.math.BigInteger;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.BankService;
import com.cg.ibs.cardmanagement.service.BankServiceImpl;
import com.cg.ibs.cardmanagement.service.CreditCustomer;
import com.cg.ibs.cardmanagement.service.CreditCustomerClassImpl;
import com.cg.ibs.cardmanagement.service.CreditCustomerVerification;
import com.cg.ibs.cardmanagement.service.CreditCustomerVerificationImpl;
import com.cg.ibs.cardmanagement.service.CustomerService;
import com.cg.ibs.cardmanagement.service.CustomerServiceImpl;
import com.cg.ibs.cardmanagement.service.DebitCustomer;
import com.cg.ibs.cardmanagement.service.DebitCustomerClassImpl;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerification;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerificationImpl;

public class CardManagementUI {

	// static BigInteger accountNumber = null;
	static Scanner scan = new Scanner(System.in);
	static BigInteger debitCardNumber = null;
	static BigInteger creditCardNumber = null;
	static int userInput = -1;
	static int userInputCust = -1;
	static int ordinal = -1;
	static String pin = null;
	static String type = null;
	static BigInteger transactionId;
	static boolean success = false;
	static int myChoice = -1;

	boolean check = false;
	static String customerReferenceId = null;
	static int newCardType = -1;
	static int days = 0;
	CreditCustomerVerification creditVerify = new CreditCustomerVerificationImpl();
	CreditCustomer creditCustomer = new CreditCustomerClassImpl();
	CustomerService customerService = new CustomerServiceImpl();
	DebitCustomer debitCustomer = new DebitCustomerClassImpl();
	DebitCustomerVerification debitVerify = new DebitCustomerVerificationImpl();
	BankService bankService = new BankServiceImpl();

	public void doIt() {
		while (true) {
			success = false;
			System.out.println("Welcome to card management System");
			System.out.println("Enter 1 to login as a customer");
			System.out.println("Enter 2 to login as a bank admin");

			while (!success) {

				try {

					userInput = scan.nextInt();
					success = true;
				} catch (InputMismatchException wrongFormat) {
					scan.next();
					System.out.println("Enter between 1 or 2");

				}
			}

			if (userInput == 1) {
				success = false;
				System.out.println("You are logged in as a customer.....");
				System.out.println("....................................");
				System.out.println("Enter 1 for Debit Card Operations....");
				System.out.println("Enter 2 for Credit Card Operations....");
				while (!success) {
					try {

						userInputCust = scan.nextInt();
						success = true;
					} catch (InputMismatchException wrongFormat) {
						scan.next();
						System.out.println("Enter between 1 or 2");

					}
				}
				if (userInputCust == 1) {
					CustomerDebit ccchoice = null;
					while (ccchoice != CustomerDebit.CUSTOMER_LOG_OUT) {

						System.out.println("Menu");
						System.out.println("--------------------");
						System.out.println("Choice");
						System.out.println("--------------------");
						System.out.println("Press x to exit");
						for (CustomerDebit mmenu : CustomerDebit.values()) {
							System.out.println((mmenu.ordinal() + 1) + "\t" + mmenu);
						}
						System.out.println("Choice");
						success = false;
						while (!success) {

							try {
								ordinal = scan.nextInt();
								success = true;
							} catch (InputMismatchException wrongFormat) {
								scan.next();
								System.out.println("Choose a valid option");
							} catch (ArrayIndexOutOfBoundsException b) {
								System.out.println(" Choose  1/2/3/4/5/6/7/8/9/10/11");
								scan.next();

							}
						}
						if (ordinal >= 1 && ordinal <= 12) {
							ccchoice = CustomerDebit.values()[ordinal - 1];

							switch (ccchoice) {

							case LIST_EXISTING_DEBIT_CARDS:

								listExistingDebitCards();
								break;

							case APPLY_NEW_DEBIT_CARD:
								applyNewDebitCard();
								break;
							case ACTIVATE_DEBIT_CARD:

								activateDebitCard();

								break;

							case DEACTIVATE_DEBIT_CARD:

								deactivateDebitCard();

								break;

							case UPGRADE_EXISTING_DEBIT_CARD:

								upgradeExistingDebitCard();
								break;

							case RESET_DEBIT_CARD_PIN:
								resetDebitCardPin();

								break;

							case REPORT_DEBIT_CARD_LOST:

								reportDebitCardLost();

								break;

							case REQUEST_DEBIT_CARD_STATEMENT:
								requestDebitCardStatement();

								break;

							case REPORT_DEBITCARD_STATEMENT_MISMATCH:

								reportDebitStatementMismatch();
								break;

							case CUSTOMER_LOG_OUT:
								System.out.println("LOGGED OUT");
								break;
							case VIEW_REQUEST_STATUS:
								viewQueryStatus();

								break;
							}
						}
					}
				} else if (userInputCust == 2) {

					CustomerCredit chhoice = null;
					while (chhoice != CustomerCredit.CUSTOMER_LOG_OUT) {

						System.out.println("Menu");
						System.out.println("--------------------");
						System.out.println("Choice");
						System.out.println("--------------------");
						System.out.println("Press x to exit");
						for (CustomerCredit mmenu : CustomerCredit.values()) {
							System.out.println((mmenu.ordinal() + 1) + "\t" + mmenu);
						}
						System.out.println("Choice");
						success = false;
						while (!success) {

							try {
								ordinal = scan.nextInt();
								success = true;
							} catch (InputMismatchException wrongFormat) {
								scan.next();
								System.out.println("Choose a valid option");
							} catch (ArrayIndexOutOfBoundsException b) {
								scan.next();
								System.out.println(" Choose  1/2/3/4/5/6/7/8/9/10/11");
							}
						}
						if (ordinal >= 1 && ordinal <= 12) {
							chhoice = CustomerCredit.values()[ordinal - 1];

							switch (chhoice) {

							case LIST_EXISTING_CREDIT_CARDS:

								listExistingCreditCards();
								break;
							case APPLY_NEW_CREDIT_CARD:
								applyNewCreditCard();
								break;
							case ACTIVATE_CREDIT_CARD:

								activateCreditCard();

								break;

							case DEACTIVATE_CREDIT_CARD:

								deactivateCreditCard();

								break;
							case UPGRADE_EXISTING_CREDIT_CARD:
								upgradeExistingCreditCard();
								break;
							case RESET_CREDIT_CARD_PIN:
								resetCreditCardPin();
								break;
							case REPORT_CREDIT_CARD_LOST:
								reportCreditCardLost();
								break;
							case REQUEST_CREDIT_CARD_STATEMENT:
								requestCreditCardStatement();
								break;
							case REPORT_CREDITCARD_STATEMENT_MISMATCH:
								reportCreditStatementMismatch();
								break;
							case CUSTOMER_LOG_OUT:
								System.out.println("LOGGED OUT");
								break;
							case VIEW_REQUEST_STATUS:
								viewQueryStatus();
							}
						}

					}
				}
			} else {
				if (userInput == 2) {

					System.out.println("You are logged in as a Bank Admin");
					BankMenu cchoice = null;
					while (cchoice != BankMenu.BANK_LOG_OUT) {
						System.out.println("Menu");
						System.out.println("--------------------");
						System.out.println("Choice");
						System.out.println("--------------------");
						for (BankMenu mmenu : BankMenu.values()) {
							System.out.println((mmenu.ordinal() + 1) + "\t" + mmenu);
						}
						System.out.println("Choice");
						success = false;
						while (!success) {
							try {
								ordinal = scan.nextInt();
								success = true;
							} catch (InputMismatchException wrongFormat) {
								scan.next();
								System.out.println("Enter a valid  option");
							} catch (ArrayIndexOutOfBoundsException b) {
								scan.next();
								System.out.println(" Choose  1/2/3/4/5");
							}
						}

						if (ordinal >= 1 && ordinal <= 6) {
							cchoice = BankMenu.values()[ordinal - 1];

							switch (cchoice) {

							case LIST_QUERIES:

								listPendingQueries();
								break;

							case REPLY_QUERIES:
								replyQueries();
								break;
							case VIEW_DEBIT_CARD_STATEMENT:
								viewBankDebitCardStatement();

								break;
							case VIEW_CREDIT_CARD_STATEMENT:
								viewBankCreditCardStatement();
								break;
							case BANK_LOG_OUT:
								System.out.println("LOGGED OUT");
								break;

							}
						}
					}
				} else {
					System.out.println("Invalid Option!!");

				}

			}

		}
	}

	void listExistingDebitCards() {
		List<DebitCardBean> debitCardBeans;
		try {
			debitCardBeans = debitCustomer.viewAllDebitCards();

			if (debitCardBeans.isEmpty()) {
				System.out.println("No Existing Debit Cards");
			} else {

				for (DebitCardBean debitCardBean : debitCardBeans) {

					System.out.println("Debit Card Number             :\t" + debitCardBean.getCardNumber());
					System.out.println("Type                          :\t" + debitCardBean.getCardType());

					System.out.println("Name                          :\t" + debitCardBean.getNameOnCard());
					System.out.println("Status                        :\t  " + debitCardBean.getCardStatus());
					System.out.println("Date of expiry(yyyy/MM/dd)    :\t" + debitCardBean.getDateOfExpiry());
					// System.out.println(debitCardBean.getAccountBeanObject().getAccountNumber());
					System.out.println("......................................................");
				}
			}
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	void listExistingCreditCards() {

		List<CreditCardBean> creditCardBeans;
		try {
			creditCardBeans = creditCustomer.viewAllCreditCards();

			if (creditCardBeans.isEmpty()) {
				System.out.println("No Existing Credit Cards");
			} else {
				int index = 1;
				for (CreditCardBean creditCardBean : creditCardBeans) {

					System.out.println("Credit Card Number                    :\t" + creditCardBean.getCardNumber());
					System.out.println("Credit Card Status                    :\t" + creditCardBean.getCardStatus());
					System.out.println("Name on Credit card                   :\t" + creditCardBean.getNameOnCard());
					System.out.println("Date of expiry(yyyy/MM/dd)            :\t" + creditCardBean.getDateOfExpiry());
					System.out.println("Credit card type                      :\t" + creditCardBean.getCardType());

					System.out.println("......................................................");
				}
//				String format = "%1$-10s%2$-25s%3$-23s%4$-20s%5$-20s%5$-25s\n";
//				String string0 = "Sr.no";
//				String string = "Credit card Number";
//				String string1 = "Card Status";
//				String string2 = "Name on Card.";
//				String string3 = "Date of Expiry";
//				String string4 = "Card Type";
//				System.out.println(
//						"----------------------------------------------------------------------------------------------------------");
//				System.out.format(format, string0, string, string1, string2, string3, string4);
//				System.out.println(
//						"----------------------------------------------------------------------------------------------------------");
//				for (CreditCardBean creditCardBean : creditCardBeans) {
//					System.out.format(format, index++, creditCardBean.getCardNumber(), creditCardBean.getCardStatus(),
//							creditCardBean.getNameOnCard(), creditCardBean.getDateOfExpiry(),
//							creditCardBean.getCardType());
//				}
			}
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	void applyNewDebitCard() {
		BigInteger accountNumber = null;
		try {
			check = debitCustomer.checkDebitCardCount();
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		if (check) {
			int accountChoice = -1;
			success = false;
			System.out.println("You are applying for a new Debit Card");
			System.out.println("To exit, press x");
			while (!success) {

				try {

					List<AccountBean> accounts = debitCustomer.getAccountList();
					int count = 1;
					for (AccountBean account : accounts) {
						System.out.println("Sr No                         :\t" + count++);
						System.out.println("Account Number                :\t" + account.getAccountNumber());

						System.out.println(".......................................................");
					}
					System.out.println("Choose Account Number you want to apply debit card for :");

					accountChoice = scan.nextInt();
					accountNumber = accounts.get(accountChoice - 1).getAccountNumber();
					System.out.println(accountNumber);
					success = true;
				} catch (InputMismatchException wrongFormat) {

					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Choose a valid option");

				} catch (IBSException notFound) {
					System.out.println(notFound.getMessage());

				}
			}

			success = false;
			while (!success) {

				try {
					System.out.println("We offer three kinds of Debit Cards:");
					System.out.println(".....................................");
					System.out.println("1 for  Platinum");
					System.out.println("2 for  Gold");
					System.out.println("3 for Silver");
					System.out.println("Choose between 1 to 3");

					newCardType = scan.nextInt();

					System.out.println("You have applied for: " + customerService.getNewCardtype(newCardType));
					System.out.println(accountNumber);
					customerReferenceId = debitCustomer.applyNewDebitCard(accountNumber,
							customerService.getNewCardtype(newCardType));
					System.out.println("Application for new debit card success!!");
					System.out.println("Your reference Id is " + customerReferenceId);
					success = true;

				} catch (InputMismatchException cardNew) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 1/2/3");

				} catch (IBSException cardNew) {
					System.out.println(cardNew.getMessage());

				}

			}
		} else {
			System.out.println("You already have 3 Active cards on this account");
		}

	}

	void applyNewCreditCard() {
		BigInteger uci = null;
		success = false;
		System.out.println("You are applying for a new Credit Card");
		System.out.println("To exit, press x");
		while (!success) {
			try {

				System.out.println("Enter your uci");
				uci = scan.nextBigInteger();
				check = customerService.verifyUci(uci);
				success = true;
			} catch (InputMismatchException wrongFormat) {

				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Renter valid uci");

			} catch (IBSException notFound) {
				System.out.println(notFound.getMessage());
			}
		}
		if (check) {
			success = false;
			while (!success) {

				try {

					System.out.println("We offer three kinds of Credit Cards:");
					System.out.println(".....................................");
					System.out.println("1 for  Platinum");
					System.out.println("2 for  Gold");
					System.out.println("3 for Silver");
					System.out.println("Choose between 1 to 3");

					newCardType = scan.nextInt();

					System.out.println("You have applied for: " + customerService.getNewCardtype(newCardType));
					customerReferenceId = creditCustomer.applyNewCreditCard(customerService.getNewCardtype(newCardType),
							uci);
					System.out.println("Application for new Credit card success!!");

					System.out.println("Your reference Id is " + customerReferenceId);
					success = true;

				} catch (InputMismatchException cardNew) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 1/2/3");

				} catch (IBSException cardNew) {
					System.out.println(cardNew.getMessage());

				}

			}
		}
	}

	void printDebitCards(List<DebitCardBean> unblockedCards) {
		int index = 1;
		for (DebitCardBean debitCardBean : unblockedCards) {
			System.out.println("Sr no.                        :\t" + index++);
			System.out.println("Debit Card Number             :\t" + debitCardBean.getCardNumber());
			System.out.println("Type                          :\t" + debitCardBean.getCardType());
			System.out.println("Name                          :\t" + debitCardBean.getNameOnCard());
			System.out.println("Date of expiry(yyyy/MM/dd)    :\t" + debitCardBean.getDateOfExpiry());
			System.out.println("Debit Card Status             :\t" + debitCardBean.getCardStatus());

			System.out.println("......................................................");
		}

	}

	void printCreditCards(List<CreditCardBean> unblockedCards) {
		int index = 1;
		for (CreditCardBean creditCardBean : unblockedCards) {
			System.out.println("Sr no.                        :\t" + index++);
			System.out.println("Credit Card Number             :\t" + creditCardBean.getCardNumber());
			System.out.println("Type                          :\t" + creditCardBean.getCardType());
			System.out.println("Name                          :\t" + creditCardBean.getNameOnCard());
			System.out.println("Date of expiry(yyyy/MM/dd)    :\t" + creditCardBean.getDateOfExpiry());
			System.out.println("Credit Card Status            :\t" + creditCardBean.getCardStatus());

			System.out.println("......................................................");
		}

	}

	void upgradeExistingDebitCard() {

		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::");

		try {

			unblockedCards = debitCustomer.getUnblockedDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;
		String mString = null;
		System.out.println(" Choose Debit Card you want to upgrade.................. ");
		System.out.println("To exit, press x");
		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				type = unblockedCards.get(debitCardChoice - 1).getCardType();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			}
		}

		if (type.equalsIgnoreCase("Silver")) {
			System.out.println("Choose 1 to upgrade to Gold");
			System.out.println("Choose 2 to upgrade to Platinum");

			success = false;
			while (!success) {
				try {
					myChoice = scan.nextInt();
					mString = customerService.checkMyChoice(myChoice);
					System.out.println("You have applied for " + mString);

					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Choose between 1 or 2");

				} catch (IBSException e) {
					System.out.println(e.getMessage());
				}
			}
			try {
				System.out.println("Ticket Raised successfully . Your reference Id is "
						+ debitCustomer.requestDebitCardUpgrade(debitCardNumber, mString));
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		} else if (type.equalsIgnoreCase("Gold")) {
			System.out.println("Choose 2 to upgrade to Platinum");
			success = false;

			while (!success) {
				try {
					myChoice = scan.nextInt();
					mString = customerService.checkMyChoiceGold(myChoice);
					System.out.println("You have chosen " + mString);
					success = true;

				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 2 to upgrade");

				} catch (IBSException e) {
					System.out.println(e.getMessage());
				}
			}
			try {
				System.out.println("Ticket Raised successfully . Your reference Id is "
						+ debitCustomer.requestDebitCardUpgrade(debitCardNumber, mString));
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}

		} else {
			System.out.println("You already have a Platinum Card");
		}

	}

	void upgradeExistingCreditCard() {

		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::");

		try {

			unblockedCards = creditCustomer.getUnblockedCreditCards();
			printCreditCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;
		System.out.println("To exit, press x");
		System.out.println(" Choose Credit Card you want to upgrade.................. ");
		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();

				type = unblockedCards.get(creditCardChoice - 1).getCardType();

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			}
		}
		if (type.equalsIgnoreCase("Silver")) {
			System.out.println("Choose 1 to upgrade to Gold");
			System.out.println("Choose 2 to upgrade to Platinum");

			success = false;
			while (!success) {
				try {
					myChoice = scan.nextInt();

					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Choose between 1 or 2");

				}
			}
			try {
				System.out.println("Ticket Raised successfully . Your reference Id is "
						+ creditCustomer.requestCreditCardUpgrade(creditCardNumber, myChoice));
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		} else if (type.equalsIgnoreCase("Gold")) {
			System.out.println("Choose 2 to upgrade to Platinum");
			success = false;

			while (!success) {
				try {
					myChoice = scan.nextInt();
					System.out.println(customerService.checkMyChoiceGold(myChoice));
					success = true;

				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 2 to upgrade");

				} catch (IBSException e) {
					System.out.println(e.getMessage());
				}
			}
			try {
				System.out.println("Ticket Raised successfully . Your reference Id is "
						+ creditCustomer.requestCreditCardUpgrade(creditCardNumber, myChoice));
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}

		} else {
			System.out.println("You already have a Platinum Card");
		}

	}

	void resetDebitCardPin() {
		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::");

		try {

			unblockedCards = debitCustomer.getUnblockedDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;

		System.out.println(" Choose Debit Card .................. ");
		System.out.println("To exit, press x");
		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			}
		}

		System.out.println("Enter your existing pin:");

		success = false;
		while (!success) {
			try {

				pin = scan.next();

				if (debitVerify.verifyDebitPin(pin, debitCardNumber)) {
					System.out.println("Enter new pin");
					success = false;
					while (!success) {
						try {

							pin = scan.next();
							debitVerify.verifyDebitCardPin(pin);

							System.out.println("Re-enter your new pin");
							String rpin = scan.next();

							if (rpin.equals(pin)) {
								debitCustomer.resetDebitPin(debitCardNumber, pin);
								System.out.println("PIN CHANGED SUCCESSFULLY!!!");
								success = true;
							} else {
								System.out.println("PINS DO NOT MATCH...TRY AGAIN");
								success = true;
							}

						}

						catch (InputMismatchException wrongFormat) {
							System.out.println("Enter a valid 4 digit pin");
							scan.next();

						} catch (IBSException ExceptionObj) {
							System.out.println(ExceptionObj.getMessage());

						}
					}

				} else {

					System.out.println("You have entered wrong pin ");
					System.out.println("Try again");
				}

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Enter a valid 4 digit pin");
				scan.next();

			} catch (IBSException ExceptionObj) {
				System.out.println(ExceptionObj.getMessage());

			}
		}

	}

	public void resetCreditCardPin() {

		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::");

		try {

			printCreditCards(creditCustomer.getUnblockedCreditCards());

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;
		System.out.println("To exit, press x");
		System.out.println(" Choose Credit Card .................. ");
		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			}
		}

		System.out.println("Enter your existing pin:");
		success = false;
		while (!success) {
			try {

				String pin = scan.next();

				if (creditVerify.verifyCreditPin(pin, creditCardNumber)) {

					System.out.println("Enter new pin");
					success = false;
					while (!success) {
						try {

							pin = scan.next();
							creditVerify.checkCreditPin(pin);

							System.out.println("Re-enter your new pin");
							String rpin = scan.next();

							if (rpin.equals(pin)) {
								creditCustomer.resetCreditPin(creditCardNumber, pin);
								System.out.println("PIN CHANGED SUCCESSFULLY!!!");
								success = true;
							} else {
								System.out.println("PINS DO NOT MATCH...TRY AGAIN");
								success = true;
							}

						}

						catch (InputMismatchException wrongFormat) {
							System.out.println("Enter a valid 4 digit pin");
							if (scan.next().equalsIgnoreCase("x"))
								return;

						} catch (IBSException ExceptionObj) {
							System.out.println(ExceptionObj.getMessage());

						}
					}

				} else {

					System.out.println("You have entered wrong pin ");
					System.out.println("Try again");
				}
				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Enter a valid 4 digit pin");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IBSException ExceptionObj) {
				System.out.println(ExceptionObj.getMessage());

			}
		}
	}

	void reportDebitCardLost() {

		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::");

		try {

			unblockedCards = debitCustomer.getUnblockedDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;

		System.out.println(" Choose Debit Card .................. ");
		System.out.println("To exit, press x");
		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				debitCustomer.requestDebitCardLost(debitCardNumber);
				System.out.println("Your card has been BLOCKED. Contact branch for further process.");
				success = true;

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			} catch (IBSException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println(e.getMessage());
			}

		}

	}

	void activateDebitCard() {

		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::");

		try {

			unblockedCards = debitCustomer.getInactiveDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;

		System.out.println(" Choose Debit Card .................. ");
		System.out.println("To exit, press x");
		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				debitCustomer.activateDebitCard(debitCardNumber);
				System.out.println("Card successfully activated....");
				success = true;

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			} catch (IBSException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println(e.getMessage());
			}

		}
	}

	void deactivateDebitCard() {

		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::");

		try {

			unblockedCards = debitCustomer.getUnblockedDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;

		System.out.println(" Choose Debit Card .................. ");
		System.out.println("To exit, press x");
		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				debitCustomer.deactivateDebitCard(debitCardNumber);
				System.out.println("Card successfully deactivated....");
				success = true;

			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		}

	}

	void activateCreditCard() {
		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::");

		try {

			printCreditCards(creditCustomer.getInactiveCreditCards());

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;
		System.out.println("To exit, press x");
		System.out.println(" Choose Credit Card .................. ");
		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();
				creditCustomer.activateCreditCard(creditCardNumber);
				System.out.println("Card successfully activated....");
				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		}

	}

	void deactivateCreditCard() {

		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::");

		try {

			printCreditCards(creditCustomer.getUnblockedCreditCards());

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;
		System.out.println("To exit, press x");
		System.out.println(" Choose Credit Card .................. ");
		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();

				creditCustomer.deactivateCreditCard(creditCardNumber);
				System.out.println("Card successfully deactivated....");

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		}

	}

	void reportCreditCardLost() {

		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::");

		try {

			printCreditCards(creditCustomer.getUnblockedCreditCards());

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;
		System.out.println("To exit, press x");
		System.out.println(" Choose Credit Card .................. ");
		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();

				creditCustomer.requestCreditCardLost(creditCardNumber);
				System.out.println("Your card has been BLOCKED. Contact branch for further process.");
				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IBSException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println(e.getMessage());
			}
		}

	}

	void requestDebitCardStatement() {

		success = false;
		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::");

		try {

			unblockedCards = debitCustomer.getUnblockedDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;

		System.out.println(" Choose Debit Card .................. ");
		System.out.println("To exit, press x");
		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			}
		}

		success = false;
		while (!success) {
			try {
				System.out.println("enter days : ");
				days = scan.nextInt();
				customerService.checkDays(days);
				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Not a valid format");
			} catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}

		try {
			List<DebitCardTransaction> debitCardBeanTrns = debitCustomer.getDebitTransactions(days, debitCardNumber);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
			String format = "%1$-20s%2$-25s%3$-23s%4$-20s%5$-25s\n";
			String string = "transaction Id";
			String string1 = "UCI";
			String string2 = "Date Of trans.";
			String string3 = "Amount";
			String string4 = "Description";
			System.out.println(
					"----------------------------------------------------------------------------------------------------------");
			System.out.format(format, string, string1, string2, string3, string4);
			System.out.println(
					"----------------------------------------------------------------------------------------------------------");
			for (DebitCardTransaction debitCardTrns : debitCardBeanTrns) {
				System.out.format(format, debitCardTrns.getTransactionId(), debitCardTrns.getUCI(),
						formatter.format(debitCardTrns.getTransactionDate()), debitCardTrns.getTransactionAmount(),
						debitCardTrns.getTransactionDescription());
			}
		}

		catch (IBSException newException) {
			System.out.println(newException.getMessage());

		}

	}

	void requestCreditCardStatement() {
		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::");

		try {

			printCreditCards(creditCustomer.getUnblockedCreditCards());

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;
		System.out.println("To exit, press x");
		System.out.println(" Choose Credit Card .................. ");
		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			}
		}

		success = false;

		while (!success) {
			try {
				System.out.println("enter days : ");
				days = scan.nextInt();
				customerService.checkDays(days);
				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Not a valid format");

			} catch (IBSException e) {

				System.out.println(e.getMessage());

			}
		}

		try {
			List<CreditCardTransaction> creditCardBeanTrns = creditCustomer.getCreditTrans(days, creditCardNumber);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
			String format = "%1$-20s%2$-25s%3$-23s%4$-20s%5$-25s\n";
			String string = "transaction Id";
			String string1 = "UCI";
			String string2 = "Date Of trans.";
			String string3 = "Amount";
			String string4 = "Description";
			System.out.println(
					"----------------------------------------------------------------------------------------------------------");
			System.out.format(format, string, string1, string2, string3, string4);
			System.out.println(
					"----------------------------------------------------------------------------------------------------------");
			for (CreditCardTransaction creditCardTrns : creditCardBeanTrns) {
				System.out.format(format, creditCardTrns.getTransactionId(), creditCardTrns.getUCI(),
						formatter.format(creditCardTrns.getDateOfTran()), creditCardTrns.getAmount(),
						creditCardTrns.getDescription());
			}

		}

		catch (IBSException e) {

			System.out.println(e.getMessage());

		}

	}

	void reportDebitStatementMismatch() {

		success = false;
		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your transaction id");

				transactionId = scan.nextBigInteger();
				check = debitVerify.checkDebitTransactionId(transactionId);
				if (check) {
					System.out.println("Enter details regarding the mismatch:");
					String remarks = scan.next();

					System.out.println("Ticket Raised successfully . Your reference Id is "
							+ debitCustomer.raiseDebitMismatchTicket(transactionId, remarks));

					success = true;
				}
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;

				System.out.println("Not a valid format");

			} catch (IBSException e) {

				System.out.println(e.getMessage());

			}
		}
	}

	void reportCreditStatementMismatch() {
		success = false;
		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your transaction id");
				transactionId = scan.nextBigInteger();
				check = creditVerify.verifyCreditCardTransactionId(transactionId);
				if (check) {
					System.out.println("Ticket Raised successfully . Your reference Id is "
							+ creditCustomer.raiseCreditMismatchTicket(transactionId));
					success = true;
				}
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;

				System.out.println("Not a valid format");
			} catch (IBSException e) {
				System.out.println(e.getMessage());

			}
		}

	}

	void viewQueryStatus() {
		success = false;
		while (!success) {
			System.out.println("To exit, press x");
			System.out.println("Enter your Unique Reference ID");
			try {
				if ((customerReferenceId = scan.next()).equalsIgnoreCase("x"))
					return;

				System.out.println(customerService.viewServiceRequestStatus(customerReferenceId));
				success = true;
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			} catch (NullPointerException n) {
				System.out.println("Not Found");

			}
		}

	}

	List<CaseIdBean> listPendingQueries() {
		List<CaseIdBean> caseBeans = null;
		try {
			caseBeans = bankService.viewQueries();
			if (caseBeans.isEmpty()) {
				System.out.println("No Existing Queries");
			} else {
				int index = 1;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY hh:mm:ss");
				String format = "%1$-25s%2$-25s%3$-20s%4$-20s%5$-20s%6$-20s%7$-20s%8$-20s%8$-30s\n";
				String string0 = "Sr No.";
				String string = "Case Id";
				String string1 = "Request Date & Time";
				String string2 = "Request Status";
				String string3 = "Account No";
				String string4 = "UCI";
				String string5 = "Description";
				String string6 = "Card Number";
				String string7 = "Customer Ref. Id";
				System.out.println(
						"---------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.format(format, string0, string, string1, string2, string3, string4, string5, string6,
						string7);
				System.out.println(
						"---------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				for (CaseIdBean caseId : caseBeans) {
					System.out.format(format, index++, caseId.getCaseIdTotal(),
							formatter.format(caseId.getCaseTimeStamp()), caseId.getStatusOfServiceRequest(),
							caseId.getAccountNumber(), caseId.getUCI(), caseId.getDefineServiceRequest(),
							caseId.getCardNumber(), caseId.getCustomerReferenceId());
				}
			}

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
		return caseBeans;
	}

	void replyQueries() {
		String queryId = null;
		int newStatus = -1;
		success = false;
		String serviceRequest = null;

		List<CaseIdBean> pendingServiceRequests = null;

		int serviceRequestChoice = -1;
		System.out.println("The pending requests  are :::");

		pendingServiceRequests = listPendingQueries();

		System.out.println("................................");
		success = false;
		System.out.println("To exit, press x");
		System.out.println(" Choose service request to handle .................. ");
		while (!success) {

			try {
				serviceRequestChoice = scan.nextInt();

				serviceRequest = pendingServiceRequests.get(serviceRequestChoice - 1).getCaseIdTotal();

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Service Request ID");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			}
		}

		success = false;
		while (!success) {
			System.out.println("Select new Status from the following list:");
			System.out.println("..........................................");
			System.out.println("1 for Approved...... ");
			System.out.println("2 for In Process.....");
			System.out.println("3 for Disapproved ...");

			String newQueryStatus;
			try {
				newStatus = scan.nextInt();
				newQueryStatus = bankService.getNewQueryStatus(newStatus);

				System.out.println(" You have chosen " + newQueryStatus);

				bankService.setQueryStatus(serviceRequest, newQueryStatus);

				success = true;
			} catch (IBSException e) {
				System.out.println(e.getMessage());

			} catch (InputMismatchException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Enter 1/2/3");

			}

		}

	}

	void viewBankDebitCardStatement() {
		success = false;

		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your Debit Card Number: ");
				debitCardNumber = scan.nextBigInteger();
				check = bankService.verifyDebitCardNumber(debitCardNumber);

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Not a valid format");
			} catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}
		success = false;
		if (check) {
			while (!success) {
				try {
					System.out.println("enter days : ");
					days = scan.nextInt();
					bankService.checkDays(days);
					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Not a valid format");
				} catch (IBSException newException) {
					System.out.println(newException.getMessage());

				}
			}

			try {
				List<DebitCardTransaction> debitCardBeanTrns = bankService.getDebitTransactions(days, debitCardNumber);
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
				String format = "%1$-20s%2$-25s%3$-23s%4$-30s\n";
				String string = "transaction Id";
				String string1 = "UCI";
				String string2 = "Date Of trans.";
				String string3 = "Amount";
				String string4 = "Description";
				System.out.println(
						"--------------------------------------------------------------------------------------------------");
				System.out.format(format, string, string1, string2, string3, string4);
				System.out.println(
						"--------------------------------------------------------------------------------------------------");
				for (DebitCardTransaction debitCardTrns : debitCardBeanTrns) {
					System.out.format(format, debitCardTrns.getTransactionId(), debitCardTrns.getUCI(),
							formatter.format(debitCardTrns.getTransactionDate()), debitCardTrns.getTransactionAmount(),
							debitCardTrns.getTransactionDescription());
				}
			} catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}
	}

	void viewBankCreditCardStatement() {
		success = false;

		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your Credit Card Number: ");
				creditCardNumber = scan.nextBigInteger();
				check = bankService.verifyCreditCardNumber(creditCardNumber);

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Not a valid format");

			} catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}
		success = false;
		if (check) {
			while (!success) {
				try {
					System.out.println("enter days : ");
					days = scan.nextInt();
					bankService.checkDays(days);
					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Not a valid format");

				} catch (IBSException e) {
					System.out.println(e.getMessage());

				}
			}
			try {
				List<CreditCardTransaction> creditCardBeanTrns = bankService.getCreditTrans(days, creditCardNumber);
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
				String format = "%1$-20s%2$-25s%3$-23s%4$-30s\n";
				String string = "transaction Id";
				String string1 = "UCI";
				String string2 = "Date Of trans.";
				String string3 = "Amount";
				String string4 = "Description";
				System.out.println(
						"--------------------------------------------------------------------------------------------------");
				System.out.format(format, string, string1, string2, string3, string4);
				System.out.println(
						"--------------------------------------------------------------------------------------------------");
				for (CreditCardTransaction creditCardTrns : creditCardBeanTrns) {
					System.out.format(format, creditCardTrns.getTransactionId(), creditCardTrns.getUCI(),
							formatter.format(creditCardTrns.getDateOfTran()), creditCardTrns.getAmount(),
							creditCardTrns.getDescription());
				}
			}

			catch (IBSException e) {

				System.out.println(e.getMessage());

			}
		}
	}

	public static void main(String args[]) throws Exception {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		CardManagementUI cardManagementUI = (CardManagementUI) context.getBean("cardManagementUI");
		cardManagementUI.doIt();
		System.out.println("Program End");
		scan.close();
	}
}

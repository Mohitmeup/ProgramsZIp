package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.dao.AccountDao;
import com.cg.ibs.cardmanagement.dao.CaseIdDao;
import com.cg.ibs.cardmanagement.dao.DebitCardDao;
import com.cg.ibs.cardmanagement.dao.DebitCardTransactionDao;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

@Service
public class DebitCustomerClassImpl extends CustomerServiceImpl implements DebitCustomer {
	@Autowired
	private CaseIdDao caseIdDao;
	@Autowired
	private DebitCardTransactionDao debitCardTransactionDao;
	@Autowired
	private DebitCardDao debitCardDao;
	@Autowired
	private AccountDao accountDao;
	@Autowired
	private CaseIdBean caseIdObj;

	@Override
	public List<DebitCardBean> viewAllDebitCards() throws IBSException {
		try {
			return debitCardDao.viewAllDebitCards();
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

	}

	@Override
	public String requestDebitCardUpgrade(BigInteger debitCardNumber, String myChoice) throws IBSException {

		caseIdGenOne = "RDCU";
		timestamp = LocalDateTime.now();
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setCardNumber(debitCardNumber);
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		BigInteger accountNumber = debitCardDao.getAccountNumber(debitCardNumber);
		System.out.println(accountNumber);
		caseIdObj.setAccountNumber(accountNumber);

		caseIdObj.setUCI(accountDao.getUci(accountNumber));
		caseIdObj.setDefineServiceRequest(myChoice);

		try {
			caseIdDao.actionServiceRequest(caseIdObj);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

		return (customerReferenceID);
	}

	@Override
	public void resetDebitPin(BigInteger debitCardNumber, String pin) throws IBSException {
		try {

			debitCardDao.setNewDebitPin(debitCardNumber, pin);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

	}

	@Override
	public String applyNewDebitCard(BigInteger accountNumber, String newCardType) throws IBSException {
		caseIdGenOne = "ANDC";

		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));

		caseIdObj.setDefineServiceRequest(newCardType);

		caseIdObj.setAccountNumber(accountNumber);
		System.out.println(caseIdObj.getAccountNumber());
		caseIdObj.setCaseIdTotal(caseIdTotal);
		timestamp = LocalDateTime.now();
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");

		caseIdObj.setUCI(accountDao.getUci(accountNumber));

		caseIdObj.setCustomerReferenceId(customerReferenceID);
		caseIdDao.actionServiceRequest(caseIdObj);

		return customerReferenceID;

	}

	@Override
	public String getDebitcardType(BigInteger debitCardNumber) throws IBSException {
		String type;

		try {
			type = debitCardDao.getdebitCardType(debitCardNumber);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

		return type;

	}

	@Override

	public void requestDebitCardLost(BigInteger debitCardNumber) throws IBSException {

		try {

			debitCardDao.blockDebitCard(debitCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public String raiseDebitMismatchTicket(BigInteger transactionId, String remarks) throws IBSException {

		caseIdGenOne = "RDMT";
		BigInteger debitCardNumber = debitCardTransactionDao.getDebitCardNumber(transactionId);
		timestamp = LocalDateTime.now();
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setAccountNumber(debitCardDao.getDMAccountNumber(debitCardNumber));
		caseIdObj.setUCI(debitCardTransactionDao.getDMUci(transactionId));
		caseIdObj.setCustomerRemarks(remarks);

		caseIdObj.setCardNumber(debitCardTransactionDao.getDebitCardNumber(transactionId));

		caseIdObj.setDefineServiceRequest("Transaction ID" + transactionId);
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		try {
			caseIdDao.actionServiceRequest(caseIdObj);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

		return (customerReferenceID);

	}

	@Override
	public List<DebitCardTransaction> getDebitTransactions(int days, BigInteger debitCardNumber) throws IBSException {
		List<DebitCardTransaction> debitCardBeanTrns = debitCardTransactionDao.getDebitTrans(days, debitCardNumber);
		if (debitCardBeanTrns.isEmpty())
			throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
		return debitCardBeanTrns;

	}

	@Override
	public List<DebitCardBean> getUnblockedDebitCards() throws IBSException {
		try {
			return debitCardDao.viewAllUnblockedDebitCards();
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}

	}

	@Override
	public List<AccountBean> getAccountList() throws IBSException {
		List<AccountBean> accounts = null;
		try {
			accounts = debitCardDao.getAccountList();
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.NO_EXISTING_ACCOUNTS);
		}
		return accounts;
	}

	@Override
	public boolean checkDebitCardCount() throws IBSException {
		boolean check = true;
		try {
			List<DebitCardBean> debList = debitCardDao.viewAllUnblockedDebitCards();
			if (debList.size() == 3)
				check = false;
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}
		return check;

	}

	@Override

	public void activateDebitCard(BigInteger debitCardNumber) throws IBSException {

		try {

			debitCardDao.activateDebitCard(debitCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override

	public void deactivateDebitCard(BigInteger debitCardNumber) throws IBSException {

		try {

			debitCardDao.deactivateDebitCard(debitCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public List<DebitCardBean> getInactiveDebitCards() throws IBSException {
		try {
			return debitCardDao.viewAllInactiveDebitCards();
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}
	}

}
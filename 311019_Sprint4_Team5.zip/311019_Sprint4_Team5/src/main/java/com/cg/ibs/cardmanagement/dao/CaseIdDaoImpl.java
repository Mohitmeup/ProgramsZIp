package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CaseIdDaoImpl implements CaseIdDao {
	private static Logger logger = Logger.getLogger(CaseIdDaoImpl.class);

	private EntityManager entityManager;
	private EntityTransaction entityTransaction;

	public CaseIdDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
		entityTransaction = entityManager.getTransaction();
	}

	@Override
	public boolean verifyQueryId(String queryId) throws IBSException {
		boolean result = false;
		
		try {
		CaseIdBean d = entityManager.find(CaseIdBean.class, queryId);
		if (d != null)
			result = true;}
		catch (NoResultException e) {
			throw new IBSException("gf");
		}
		return result;
	}

	@Override
	public List<CaseIdBean> viewAllQueries() throws IBSException {
		logger.info("entered into viewAllQueries method of CaseIdDaoImpl class");
		TypedQuery<CaseIdBean> query = entityManager.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST,
				CaseIdBean.class);
		List<CaseIdBean> listOfQueries = query.getResultList();
		return listOfQueries;
	}

	@Override
	public void setQueryStatus(String queryId, String newStatus) throws IBSException {
		logger.info("entered into setQueryStatus method of CaseIdDaoImpl class");

		CaseIdBean query = entityManager.find(CaseIdBean.class, queryId);
		if (query != null) {
			query.setStatusOfServiceRequest(newStatus);
			entityTransaction.begin();
			entityManager.merge(query);
			entityTransaction.commit();

		}

	}

	@Override
	public String getNewType(String queryId) throws IBSException {
		logger.info("entered into getNewType method of CaseIdDaoImpl class");


		CaseIdBean caseId = entityManager.find(CaseIdBean.class, queryId);
		return caseId.getDefineServiceRequest();
	}

	@Override
	public void actionServiceRequest(CaseIdBean caseIdObj) throws IBSException {
		logger.info("entered into actionServiceRequest method of CaseIdDaoImpl class");
		entityTransaction.begin();
		entityManager.persist(caseIdObj);
		entityTransaction.commit();

	}

	@Override
	public String getCustomerReferenceStatus(CaseIdBean caseIdObj, String customerReferenceId) throws IBSException {
		logger.info("entered into getCustomerReferenceStatus method of CaseIdDaoImpl class");
		String status;
		try {
		TypedQuery<String> query = entityManager.createQuery(
				"Select d.statusOfServiceRequest from CaseIdBean d where customerReferenceId=:customerRef",
				String.class);
		query.setParameter("customerRef", customerReferenceId);
		status=query.getSingleResult();}
		catch(NoResultException e) {
			throw new IBSException(ErrorMessages.NO_CUSTREFERENCESTATUS);
		}
		return status;

	}

	@Override
	public BigInteger getNewUCI(String queryId) throws IBSException {
		logger.info("entered into getNewUCI method of CaseIdDaoImpl class");

		TypedQuery<BigInteger> query = entityManager
				.createQuery("select d.UCI from CaseIdBean d where d.caseIdTotal=:queryID", BigInteger.class);
		query.setParameter("queryID", queryId);

		return query.getSingleResult();

	}

	@Override
	public CaseIdBean getCaseObj(String queryId) {
		logger.info("entered into getCaseObj method of CaseIdDaoImpl class");
		
		CaseIdBean obj=entityManager.find(CaseIdBean.class,queryId);
		return obj;
		
	}

	

}

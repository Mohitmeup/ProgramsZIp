package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface CreditCardTransactionDao {
	boolean verifyCreditTransactionId(BigInteger transactionId) throws IBSException;

	List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) throws IBSException;

	BigInteger getCMUci(BigInteger transactionId) throws IBSException;

	BigInteger getCreditCardNumber(BigInteger transactionId) throws IBSException;

	List<CreditCardTransaction> getDebitMismatchTransc(BigInteger transactionId);

}

package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface CreditCardDao {

	List<CreditCardBean> viewAllCreditCards() throws IBSException;

	String getCreditCardPin(BigInteger creditCardNumber) throws IBSException;

	BigInteger getCreditUci(BigInteger creditCardNumber) throws IBSException;

	String getcreditCardType(BigInteger creditCardNumber) throws IBSException;

	String getCreditCardStatus(BigInteger creditCardNumber) throws IBSException;

	void setNewCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException;

	void actionUpgradeCC(String queryId) throws IBSException;

	boolean verifyCreditCardNumber(BigInteger creditCardNumber) throws IBSException;

	void actionANCC(CreditCardBean bean1) throws IBSException;

	void blockCreditCard(BigInteger creditCardNumber) throws IBSException;

	void creditMismatch(String queryId)throws IBSException;
}

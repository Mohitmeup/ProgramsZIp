package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.cg.ibs.cardmanagement.bean.CustomerBean;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CustomerDaoImpl implements CustomerDao {

	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("cardmanagement");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();

	private static Logger logger = Logger.getLogger(CustomerDaoImpl.class);

	@Override
	public String getNewName(BigInteger uci) throws IBSException {
		logger.info("entered into getNewName method of CustomerDaoImpl class");
		String fname = null;
		String lname = null;

		CustomerBean customer = null;

		TypedQuery<CustomerBean> query = entityManager.createQuery("select c from CustomerBean c where c.UCI=:uci",
				CustomerBean.class);
		query.setParameter("uci", uci);
		try {
			customer = query.getSingleResult();
			fname = customer.getFirstName();
			lname = customer.getLastName();
		} catch (NoResultException e) {

		}

		return (fname + " " + lname);

	}

	@Override
	public boolean verifyUCI(BigInteger uci) throws IBSException {
		logger.info("entered into verifyUCI method of CustomerDaoImpl class");

		boolean result = false;

		CustomerBean d = entityManager.find(CustomerBean.class, uci);

		if (d != null) {
			result = true;
		}

		return result;

	}
}
package com.cg.ibs.cardmanagement.customerservice;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigInteger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.cg.ibs.cardmanagement.dao.CustomerDao;
import com.cg.ibs.cardmanagement.dao.CustomerDaoImpl;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.CustomerService;
import com.cg.ibs.cardmanagement.service.CustomerServiceImpl;
import com.cg.ibs.cardmanagement.service.DebitCustomer;
import com.cg.ibs.cardmanagement.service.DebitCustomerClassImpl;

class DebitCustomerTestClassImpl {
	CustomerService customerService = new CustomerServiceImpl();
	CustomerDao dao = new CustomerDaoImpl();

	DebitCustomer debitCustomer = new DebitCustomerClassImpl();

	@Test
	public void requestExistingDebitCardUpgrade() {
		BigInteger debitCardNumber = new BigInteger("5221562391012233");
		String myChoice = "Silver";
		try {

			assertNotNull(debitCustomer.requestDebitCardUpgrade(debitCardNumber, myChoice));
		} catch (IBSException e) {
			fail(e.getMessage());

		}

	}

	@Test
	public void requestNonExistingDebitCardUpgrade() {
		BigInteger cardNumber = new BigInteger("5221562391012237");
		String myChoice = "hjh";
		Assertions.assertThrows(IBSException.class, () -> {
			debitCustomer.requestDebitCardUpgrade(cardNumber, myChoice);
		});

	}

	@Test
	public void resetNonExistingDebitPin() {
		BigInteger debitCardNumber = new BigInteger("5221562391012239");
		String pin = "2233";
		Assertions.assertThrows(IBSException.class, () -> {
			debitCustomer.resetDebitPin(debitCardNumber, pin);
		});

	}

	@Test
	public void applyNewDebitCard() {
		BigInteger accountNumber = new BigInteger("12345678910");
		String newCardType = "Silver";
		try {
			assertNotNull(debitCustomer.applyNewDebitCard(accountNumber, newCardType));
		} catch (IBSException e) {
			fail(e.getMessage());
		}

	}

	@Test
	public void applyNotNewDebitCard() {
		BigInteger accountNumber = new BigInteger("1234567891");
		String newCardType = "Si";
		Assertions.assertThrows(IBSException.class, () -> {
			debitCustomer.applyNewDebitCard(accountNumber, newCardType);
		});
	}

	
	@Test
	public void getDebitCardType() {
		BigInteger debitCardNumber= new BigInteger("5221562391012233");
		try {
			assertNotNull(debitCustomer.getDebitcardType(debitCardNumber));
		} catch (IBSException e) {
			fail(e.getMessage());
		}
	}
		
	@Test
	public void getNotDebitCardType() {
		BigInteger debitCardNumber= new BigInteger("522156391012233");
	
		Assertions.assertThrows(IBSException.class, () -> {
			debitCustomer.getDebitcardType(debitCardNumber);
		});
	}
		
	
//	@Test
//	public void requestdebitCardLost() {
//		
//		BigInteger debitCardNumber = new BigInteger("5221562391012233");
//		
//		try {
//
//			assertNotNull(debitCustomer.requestDebitCardLost(debitCardNumber));
//		} catch (IBSException e) {
//			fail(e.getMessage());
//
//		}
//		
//	}
	
	@Test
	public void requestNonExistingDebitCardLost() {
		BigInteger cardNumber = new BigInteger("5221562391012237");
	
		Assertions.assertThrows(IBSException.class, () -> {
			debitCustomer.requestDebitCardLost(cardNumber);
		});

	}
	
	
	@Test
	public void raiseDebitMismatch() {
		
		BigInteger transactionId = new BigInteger("1234567891");
		
		try {

			assertNotNull(debitCustomer.raiseDebitMismatchTicket(transactionId));
		} catch (IBSException e) {
			fail(e.getMessage());

		}
		
	}
	
	@Test
	public void raiseNonDebitMismatch() {
		BigInteger transactionId = new BigInteger("123547890");
	
		Assertions.assertThrows(IBSException.class, () -> {
			debitCustomer.raiseDebitMismatchTicket(transactionId);
		});

	}
	
	
	@Test
	void viewAllDebitCards() {
	try {
		assertNotNull(debitCustomer.viewAllDebitCards());
	} catch (IBSException e) {
		fail(e.getMessage());
		
	}
    					
	}
	
	
	
}

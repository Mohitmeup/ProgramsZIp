package com.cg.sd.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.sd.service.GreetService;

public class App {

	public static void main(String[] args) {
//		GreetService gs = new GreetServiceSimpleImpl();
//		System.out.println(gs.greet("Vamsy"));

		ApplicationContext ctx = new ClassPathXmlApplicationContext("mybeans.xml");

		GreetService gs = (GreetService) ctx.getBean("gs");
		System.out.println(gs.greet("Vamsy"));

//		GreetService gps = (GreetService) ctx.getBean("gs1");
//		System.out.println(gps.greet("Vamsy"));

	}
}

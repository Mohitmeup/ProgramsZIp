import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListMismatchRequestsComponent } from './list-mismatch-requests.component';

describe('ListMismatchRequestsComponent', () => {
  let component: ListMismatchRequestsComponent;
  let fixture: ComponentFixture<ListMismatchRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListMismatchRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListMismatchRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

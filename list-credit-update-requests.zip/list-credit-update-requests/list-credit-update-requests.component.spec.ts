import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCreditUpdateRequestsComponent } from './list-credit-update-requests.component';

describe('ListCreditUpdateRequestsComponent', () => {
  let component: ListCreditUpdateRequestsComponent;
  let fixture: ComponentFixture<ListCreditUpdateRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListCreditUpdateRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCreditUpdateRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

package com.cg.ibs.JpaDemo.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.transaction.Transaction;

import com.cg.ibs.JpaDemo.entity.BowBean;

public class Main {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Mohit");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		BowBean bow = new BowBean();
		bow.setBowId(12346);
		bow.setBowName("mohit bows");
		bow.setBowDescription("doggie");
		bow.setTestcase(1111);
		entityManager.persist(bow);
		entityManager.getTransaction().commit();
		entityManager.close();
		entityManagerFactory.close();

//		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Mohit");
//		EntityManager entityManager = entityManagerFactory.createEntityManager();
//		entityManager.getTransaction().begin();
//		BowBean bow = new BowBean();
//		bow.setBowDescription("yuvraj pervert");
//		bow.setBowId(422);
//		bow.setBowName("yuvraj");
//		entityManager.persist(bow);
//		entityManager.getTransaction().commit();
//		entityManager.close();
//		entityManagerFactory.close();
//		System.out.println("done");
	}
}
package com.cg.lambda;

import java.time.LocalDate;

public class Book {
	private int bookCode;
	private String title;
	private double price;
	private LocalDate date;
	
	public Book() {
		super();
	}
	
	public Book(int bookCode, String title, double price, LocalDate date) {
		super();
		this.bookCode = bookCode;
		this.title = title;
		this.price = price;
		this.date = date;
	}

	@Override
	public String toString() {
		return "Book [bookCode=" + bookCode + ", title=" + title + ", price=" + price + ", date=" + date + "]";
	}
	public int getBookCode() {
		return bookCode;
	}
	public void setBookCode(int bookCode) {
		this.bookCode = bookCode;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}

}
package com.cg.lambda;

public class Lambda {
	public static void main(final String[] args) {
		final Dummy d = new Dummy() {

			@Override
			public int doProcess(final int i) {
				return i * 5;
			}
		};
		System.out.println(d.doProcess(5));

		final Dummy d1 = (i) -> (i * i);
		System.out.println(d1.doProcess(90));
		
		Dummy d2 = (i)->{
			int fact = 1;
			for(int a=2;a<=i;a++){
				fact *=i;
			} return fact;
		};System.out.println(d2.doProcess(4));
	}
}

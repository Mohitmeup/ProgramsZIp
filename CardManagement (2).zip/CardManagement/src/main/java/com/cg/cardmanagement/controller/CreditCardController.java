package com.cg.cardmanagement.controller;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.AccBean;
import com.cg.cardmanagement.model.CardDetails;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.model.CreditApply;
import com.cg.cardmanagement.model.CreditCardBean;
import com.cg.cardmanagement.model.CreditCardTransaction;
import com.cg.cardmanagement.model.TransBean;
import com.cg.cardmanagement.model.TransBean1;
import com.cg.cardmanagement.service.CreditCustomer;
import com.cg.cardmanagement.service.CreditCustomerVerification;

@RestController
@Scope("session")
@RequestMapping("/credit")
public class CreditCardController {

	@Autowired
	private CreditCustomer creditService;
	@Autowired
	private CreditCustomerVerification creditVerify;
	List<CreditCardTransaction> trans;
	
	@GetMapping("/creditlist")
    public ResponseEntity<List<CreditCardBean>> list() throws IBSException {
      
        // List<CreditCardBean>debitCardBeans = debitService.viewAllDebitCards();
        List<CreditCardBean> creditCardBeansSorted  = creditService.viewAllSortedCreditCards();
        System.out.println(creditCardBeansSorted.toString());
        return new ResponseEntity<List<CreditCardBean>>(creditCardBeansSorted, HttpStatus.OK);

    }
	@PostMapping("/carddisplaymenu")
    //checkQuery
    public ResponseEntity<CreditCardBean> cardDetails(@RequestBody CreditCardBean d) throws IBSException {
    	BigInteger cardNumber=d.getCardNumber();
        CreditCardBean object = creditService.fetchCreditdetails(cardNumber);

        return new ResponseEntity<CreditCardBean>(object, HttpStatus.OK);
    }

	
	
	

	@PatchMapping(value = "/block")
	public ResponseEntity<CardDetails> block(@RequestBody CreditCardBean d) throws IBSException {
		CardDetails output = new CardDetails();
		String pin = d.getCurrentPin();
		BigInteger cardNumber = d.getCardNumber();
		if (creditVerify.verifyCreditCardPin(pin)) {
			if (!creditService.getCreditcardStatus(cardNumber).equalsIgnoreCase("Blocked")) {
				if (creditVerify.verifyCreditPin(pin, cardNumber)) {
					creditService.requestCreditCardLost(cardNumber);
					 output.setMessage(" Your card has been Blocked. Contact branch for further process!");
	    				output.setValue(true);
				
				} else {
					 output.setMessage("Card number and pin don't match!! Try again!");
	    				output.setValue(false);
					
				}
			} else {

				
				output.setMessage("Card already blocked");
				output.setValue(false);
			}
		} else {
			
			output.setMessage("Invalid pin format");
			output.setValue(false);

		}
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}

	@PatchMapping(value = "/activate")
	public ResponseEntity<CardDetails> activate(@RequestBody CreditCardBean d) throws IBSException {
		CardDetails output = new CardDetails();
		String pin = d.getCurrentPin();
		BigInteger cardNumber = d.getCardNumber();

		if (creditService.getCreditcardStatus(cardNumber).equalsIgnoreCase("Inactive")) {
			if (creditVerify.verifyCreditCardPin(pin)) {
				if (creditVerify.verifyCreditPin(pin, cardNumber)) {
					creditService.activateCreditCard(cardNumber);
					output.setMessage("Card successfully activated!");
					output.setValue(true);
					
				} else {
					output.setMessage( "Card number and pin don't match!! Try again!");
					output.setValue(false);
				}
			} else {
				String status = creditService.getCreditcardStatus(cardNumber);
				output.setMessage("Card already " + status);
				output.setValue(false);
				
			}

		} else {
			output.setMessage("Invalid pin format");
			output.setValue(false);

		}
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}

	@PatchMapping(value = "/deactivate")
	public ResponseEntity<CardDetails> deactivate(@RequestBody CreditCardBean d) throws IBSException {
		CardDetails output = new CardDetails();
		String pin = d.getCurrentPin();
		BigInteger cardNumber = d.getCardNumber();

		if (creditService.getCreditcardStatus(cardNumber).equalsIgnoreCase("Active")) {
			if (creditVerify.verifyCreditCardPin(pin)) {
				if (creditVerify.verifyCreditPin(pin, cardNumber)) {

					creditService.deactivateCreditCard(cardNumber);
					output.setMessage("Card successfully deactivated!");
					output.setValue(true);
				} else {
			
					output.setMessage("Card number and pin don't match!! Try again!");
					output.setValue(true);
				}
			} else {
				
				output.setMessage("Invalid pin format");
				output.setValue(false);

			}
		} else {
			String status = creditService.getCreditcardStatus(cardNumber);
			output.setMessage("Card already " + status);
			output.setValue(false);

		}
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}
	
	
	
	@GetMapping(value = "/reset") 
    public ResponseEntity<CardDetails>resetPin(@RequestBody CreditCardBean d) throws IBSException {
		CardDetails output = new CardDetails();
        String pin = d.getCurrentPin();
		BigInteger cardNumber = d.getCardNumber();
     

 

            if (creditVerify.verifyCreditPin(pin, cardNumber)) {
               
                output.setMessage("PIN VERIFIED");
                output.setValue(true);
            } else {
            	
            	output.setMessage( "PINS DO NOT MATCH!! TRY AGAIN");
				output.setValue(false);
            }
            return new ResponseEntity<CardDetails>(output, HttpStatus.OK);
        
    }
	
	
	
	
	@PatchMapping(value = "/resetpin")
	public ResponseEntity<CardDetails> resetPin2(@RequestBody CreditCardBean d) throws IBSException {
		CardDetails output = new CardDetails();
		BigInteger cardNumber = d.getCardNumber();
		String newpin = d.getCurrentPin();
       
           // if (newpin2.equals(newpin)) {
                creditService.resetCreditPin(cardNumber, newpin);
                output.setMessage("PIN SUCCESSFULLY CHANGED");
				output.setValue(true);
           
        	return new ResponseEntity<CardDetails>(output, HttpStatus.OK);
       
    }

	

	

	@PostMapping(value = "/upgrade")
    public  ResponseEntity<CardDetails> upgrade(@RequestBody CaseIdBean caseIdBean) throws IBSException  {
		CardDetails output = new CardDetails();
        String type = null;
        BigInteger cardNumber = caseIdBean.getCardNumber();
        
            if (!creditService.getCreditcardStatus(cardNumber).equalsIgnoreCase("Blocked")
                    && !creditService.getCreditcardStatus(cardNumber).equalsIgnoreCase("Inactive")) {
                type = creditService.getCreditcardType(cardNumber);
                if (type.equalsIgnoreCase("Silver")) {
                    output.setFlag(1);
                } else if (type.equalsIgnoreCase("Gold")) {
                	 output.setFlag(2);
                } else {
                	 output.setFlag(3);
                }
            } else {
                
                output.setMessage( "OOPS!!  You can not upgrade a blocked/inactive card");
				output.setValue(false);
            }
           

 
				return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

    }
	
            
            @PostMapping(value = "/upgradeTwo")
            public  ResponseEntity<CardDetails> upgrade2(@RequestBody AccBean a) throws IBSException {
            	CardDetails output = new CardDetails();
               
                BigInteger cardNumber = a.getCardNumber();
                String type=a.getType();
                String remarks=a.getRemarks();
                
                    String num = creditService.requestCreditCardUpgrade(cardNumber, type, remarks);

                    output.setMessage("Ticket Raised successfully. Your reference Id is" + num);
    				output.setValue(true);
                    
    				return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

            }


            @PostMapping(value = "/requestStatement")
	public ResponseEntity<List<CreditCardTransaction>> requestStatement(@RequestBody TransBean t) throws IBSException {
		BigInteger cardNumber = t.getCardNumber();
		String fromdate=t.getFromdate();
		String enddate=t.getEnddate();
		DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;
		CardDetails output = new CardDetails();
		LocalDate startDate1 = LocalDate.parse(fromdate, formatter);
		LocalDate endDate1 = LocalDate.parse(enddate, formatter);
		List<CreditCardTransaction> bean1 = creditService.getCreditTrans(startDate1, endDate1, cardNumber);
		return new ResponseEntity<List<CreditCardTransaction>>(bean1, HttpStatus.OK);

	}

	@PostMapping(value = "/mismatchCredit")
	public ResponseEntity<CardDetails> creditMismatch(@RequestBody TransBean1 t1) throws IBSException {
		Integer transaction=t1.getTransactionId();
		String remarks=t1.getRemarks();
		 
		  BigInteger transactionId = BigInteger.valueOf(transaction);
		
		CardDetails output = new CardDetails();
		String refId = creditService.raiseCreditMismatchTicket(transactionId, remarks);
		output.setMessage( " Ticket raised successfully. your reference ID is " + refId);
		output.setValue(true);
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}

	@PostMapping(value = "/applynewcredit")
	public ResponseEntity<CardDetails> applyNewCreditCard2(@RequestBody CreditApply a) throws IBSException {
		BigInteger uci=a.getUci();
		String type=a.getType();
	
		CardDetails output = new CardDetails();
		if (creditService.checkCreditCardCount()) {
			System.out.println("a");
			String num = creditService.applyNewCreditCard(type, uci);
			
			output.setMessage("Ticket Raised successfully. Your reference Id is" + num);
			output.setValue(true);
		} else {
			
			output.setMessage( "You already have 1 credit card.");
			output.setValue(false);

		}
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}

            
            
            
            
            
            
            
            
            
            
            
	@ExceptionHandler
	public ResponseEntity<String> ibsException(IBSException e) {

		String output = e.getMessage();
		return new ResponseEntity<String>(output, HttpStatus.OK);
	}
}

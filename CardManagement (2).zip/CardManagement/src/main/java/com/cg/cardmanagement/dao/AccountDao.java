package com.cg.cardmanagement.dao;

import java.math.BigInteger;

import com.cg.cardmanagement.exception.IBSException;

public interface AccountDao {


	boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException;
	BigInteger getUci(BigInteger accountNumber) throws IBSException;

	

}

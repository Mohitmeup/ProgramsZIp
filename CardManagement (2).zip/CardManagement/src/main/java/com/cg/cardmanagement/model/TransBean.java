package com.cg.cardmanagement.model;

import java.math.BigInteger;

public class TransBean {
	private BigInteger cardNumber;
	
    private String fromdate;
    private String enddate;
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	@Override
	public String toString() {
		return "TransBean [cardNumber=" + cardNumber + ", fromdate=" + fromdate + ", enddate=" + enddate + "]";
	}
	public TransBean(BigInteger cardNumber, String fromdate, String enddate) {
		super();
		this.cardNumber = cardNumber;
		this.fromdate = fromdate;
		this.enddate = enddate;
	}
	public BigInteger getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(BigInteger cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getFromdate() {
		return fromdate;
	}
	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}

}

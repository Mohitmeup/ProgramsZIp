package com.cg.cardmanagement.model;

public enum CreditCardStatus {

		 PENDING, BLOCKED,ACTIVE,INACTIVE
		
}

package com.cg.intro;
public interface CurrencyConverter {

	public double dollarsToRupees(double dollars);
	
}
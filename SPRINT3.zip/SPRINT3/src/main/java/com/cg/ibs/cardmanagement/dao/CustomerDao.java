
package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface CustomerDao {
	
	void  newDebitCard(CaseIdBean caseIdObj,BigInteger accountNumber)throws IBSException;
	void newCreditCard(CaseIdBean caseIdObjId)throws IBSException;
	List <DebitCardBean> viewAllDebitCards()throws IBSException;
	
	BigInteger getAccountNumber(BigInteger debitCardNumber)throws IBSException;
	String getdebitCardType(BigInteger debitCardNumber)throws IBSException;
	void requestDebitCardUpgrade(CaseIdBean caseIdObj, BigInteger debitCardNumber)throws IBSException;
	List<CreditCardBean> viewAllCreditCards()throws IBSException;
	void requestDebitCardLost(CaseIdBean caseIdObj, BigInteger debitCardNumber)throws IBSException;
	void requestCreditCardLost(CaseIdBean caseIdObj, BigInteger creditCardNumber)throws IBSException;
	boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException;
	boolean verifyDebitCardNumber(BigInteger debitCardNumber)throws IBSException;
	boolean verifyCreditCardNumber(BigInteger creditCardNumber)throws IBSException;
	void setNewDebitPin(BigInteger debitCardNumber, int newPin)throws IBSException;
	int getDebitCardPin(BigInteger debitCardNumber)throws IBSException;
	void setNewCreditPin(BigInteger creditCardNumber, int newPin)throws IBSException;
	int getCreditCardPin(BigInteger creditCardNumber)throws IBSException;
	
	 BigInteger getDebitUci(BigInteger debitCardNumber)throws IBSException;
	 BigInteger getCreditUci(BigInteger creditCardNumber)throws IBSException;

	String getcreditCardType(BigInteger creditCardNumber)throws IBSException;
	boolean verifyCreditTransactionId(String transactionId)throws IBSException;
	void raiseDebitMismatchTicket(CaseIdBean caseIdObj,String transactionId)throws IBSException;
	void raiseCreditMismatchTicket(CaseIdBean caseIdObj, String transactionId)throws IBSException;
	
	List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber)throws IBSException;
	List<DebitCardTransaction> getDebitTrans(int dys, BigInteger debitCardNumber)throws IBSException;
	
	void requestCreditCardUpgrade(CaseIdBean caseIdObj, BigInteger creditCardNumber)throws IBSException;
	
	boolean verifyDebitTransactionId(String transactionId)throws IBSException;
	String getCustomerReferenceId(CaseIdBean caseIdObj, String customerReferenceId)throws IBSException;
	String getDebitCardStatus(BigInteger debitCardNumber)throws IBSException;
	String getCreditCardStatus(BigInteger creditCardNumber)throws IBSException;
	BigInteger getDebitCardNumber(String transactionId)throws IBSException;
	BigInteger getDMUci(String transactionId)throws IBSException;

	BigInteger getCMUci(String transactionId)throws IBSException;
	BigInteger getNDCUci(BigInteger accountNumber)throws IBSException;
	BigInteger getCreditCardNumber(String transactionId)throws IBSException;
	boolean verifyUCI(BigInteger uci)throws IBSException;
	BigInteger getDMAccountNumber(BigInteger debitCardNumber)throws IBSException;
}

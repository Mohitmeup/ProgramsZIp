import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Debitmodel } from '../model/debitmodel';
import { DebitserviceService } from '../service/debitservice.service';
@Component({
  selector: 'app-show-card',
  templateUrl: './show-card.component.html',
  styleUrls: ['./show-card.component.css']
})
export class ShowCardComponent implements OnInit {
  bean: Debitmodel[];
  bean1: Debitmodel;
  constructor(private debitService: DebitserviceService, private router:Router) {
  }


  ngOnInit() {
this.getDetails();


  }
getDetails(){

  const cardNumber1 = localStorage.getItem("cardNumber");
  var cardNumber = Number(cardNumber1)
  let cardDetails = {
    cardNumber
  }
  this.debitService.getDetails(cardDetails).subscribe(
    (data) => {
      this.bean1 = data;
    }
  )}
  block(cardNumber: number) {

    let cardDetails = {
      cardNumber,
    
    }


    this.debitService.check(cardDetails).subscribe(
      data => {console.log(data.value);
        if(data.value) {
         console.log(data.value);
         console.log(data.message);
         Swal.fire({
           title: 'Oops!',
           text: (data.message),
           confirmButtonText: 'CANCEL'
         })}
         else{


  
    console.log(cardNumber)
    Swal.mixin({
      input: 'password',
      confirmButtonText: 'Block Card',
      showCancelButton: true
    }).queue([
      {
        title: 'Please Enter the PIN',
        text: 'This will block your card'
      }
    ]).then((result) => {
      if (result.value) {
        const currentPin = result.value[0]
        let cardDetails = {
          cardNumber,
          currentPin
        }
        console.log(currentPin);
         this.debitService.blockCard(cardDetails).subscribe(
          
  data => {
    console.log(data);console.log(data.value);
           if(data.value) {
            console.log(data.value);
            Swal.fire({
              title: 'All done!',
              html: `
                Your card has been blocked!
              `,
              confirmButtonText: 'DONE!'
            })
           } else {
            console.log(data.value);
           Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: (data.message),
            footer: '<a href>Why do I have this issue?</a>'
           })
        }
          
         })
      }
    })

  }}
    )
  }
  
 
  



  activate(cardNumber: number) {
    console.log(cardNumber)
    let cardDetails = {
      cardNumber,
    
    }


    this.debitService.checkActive(cardDetails).subscribe(
      data => {console.log(data.value);
        if(data.value) {
         console.log(data.value);
         console.log(data.message);
         Swal.fire({
           title: 'Oops!',
           text: (data.message),
           confirmButtonText: 'CANCEL'
         })}
         else{
         
         
         
    Swal.mixin({
      input: 'password',
      confirmButtonText: 'Activate Card',
      showCancelButton: true
    }).queue([
      {
        title: 'Please Enter the PIN',
        text: 'This will activate your card'
      }
    ]).then((result) => {
      if (result.value) {
        const currentPin = result.value[0]
        let cardDetails = {
          cardNumber,
          currentPin
        }
        console.log(currentPin);
         this.debitService.activateCard(cardDetails).subscribe(
  data => {console.log(data.value);
           if(data.value) {
            console.log(data.value);
            Swal.fire({
              title: 'All done!',
              html: `
                Your card has been activated!
              `,
              confirmButtonText: 'DONE!'
            })
           } else {
            console.log(data.value);
           Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: (data.message),
            footer: '<a href>Why do I have this issue?</a>'
           })
        }
          
         })
      }
    })
  }}
    )
  }
  
  
  deactivate(cardNumber: number) {
    console.log(cardNumber)
    let cardDetails = {
      cardNumber,
    
    }


    this.debitService.check(cardDetails).subscribe(
      data => {console.log(data.value);
        if(data.value) {
         console.log(data.value);
         console.log(data.message);
         Swal.fire({
           title: 'Oops!',
           text: (data.message),
           confirmButtonText: 'CANCEL'
         })}
         else{
         
    Swal.mixin({
      input: 'password',
      confirmButtonText: 'Deactivate Card',
      showCancelButton: true
    }).queue([
      {
        title: 'Please Enter the PIN',
        text: 'This will deactivate your card'
      }
    ]).then((result) => {
      if (result.value) {
        const currentPin = result.value[0]
        let cardDetails = {
          cardNumber,
          currentPin
        }
        console.log(currentPin);
         this.debitService.deactivateCard(cardDetails).subscribe(
  data => {console.log(data.value);
           if(data.value) {
            console.log(data.value);
            console.log(data.value);
         
            Swal.fire({
              title: 'All done!',
              text: (data.message),
              confirmButtonText: 'DONE!'
            })
           } else {
            console.log(data.value);
           Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: (data.message),
            footer: '<a href>Why do I have this issue?</a>'
           })
        }
          
         })
      }
    })
  }}
    )
  }
  
  
  
  resetPin2(cardNumber:number){
    Swal.mixin({
      input: 'password',
      confirmButtonText: 'Next &rarr;',
      showCancelButton: true,
      progressSteps: ['1', '2']
    }).queue([
      {
        title: 'New Pin',
        text: 'Enter new pin',
      },
      {
        title: 'Reconfirm',
        text: 'Renter new pin !',
      }
    ]).then((result) => {
      if (result.value) {
        console.log(result.value)
        const currentPin = result.value[0];
        const newPin2=result.value[1];
        console.log(currentPin)
        console.log(newPin2)
        if(currentPin==newPin2){
        let cardDetails = {
          cardNumber,
          currentPin 
        }
  
        console.log(currentPin)
        console.log(cardDetails)
         this.debitService.resetCard2(cardDetails).subscribe(
  data => {
    console.log(data.value);
           if(data.value) {
            console.log(data.value);
            Swal.fire({
              title: 'Correct pin Entered',
              text: (data.message),
              confirmButtonText: 'DONE!'
  
            })
            this.resetPin2(cardNumber);
            Swal.fire({
              title: 'Pin changed successfully',
              confirmButtonText: 'DONE!'
  
            })
            
           } else {
            console.log(data.value);
           Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: (data.message),
            footer: '<a href>Why do I have this issue?</a>'
           })
        }
          
         })}
         else{
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            html:`Pins do not match`,
            footer: '<a href>Why do I have this issue?</a>'
           })
         }
      }
    })
  }
  
  
  
  
  upgrade(cardNumber: number){
    console.log(cardNumber)
   localStorage.setItem("card",cardNumber.toString());
   let cardDetails = {
    cardNumber
  
  }
  
   this.debitService.check(cardDetails).subscribe(
    data => {console.log(data.value);
      if(data.value) {
       console.log(data.value);
       console.log(data.message);
       Swal.fire({
         title: 'Oops!',
         text: (data.message),
         confirmButtonText: 'CANCEL',
allowOutsideClick:false
       })}
       else{
        this.router.navigateByUrl("/debit/upgrade1");
       }}
       )
}

  
  resetPin(cardNumber: number) {
    console.log(cardNumber)
    let cardDetails = {
      cardNumber,
    
    }


    this.debitService.check(cardDetails).subscribe(
      data => {console.log(data.value);
        if(data.value) {
         console.log(data.value);
         console.log(data.message);
         Swal.fire({
           title: 'Oops!',
           text: (data.message),
           confirmButtonText: 'CANCEL',
           allowOutsideClick:false
         })}
         else{
    Swal.mixin({
      input: 'password',
      confirmButtonText: 'Reset Pin',
      showCancelButton: true
    }).queue([
      {
        title: 'Please Enter the PIN',
        text: 'Enter existing pin'
      }
    ]).then((result) => {
      if (result.value) {
        const currentPin = result.value[0]
        let cardDetails = {
          cardNumber,
          currentPin
        }
        console.log(currentPin);
        console.log(cardDetails);
         this.debitService.resetCard1(cardDetails).subscribe(
  data => {
    console.log(data);
    console.log(data.value);
           if(data.value) {
            console.log(data.value);
            Swal.fire({
              title: 'Correct pin Entered',
              text: (data.message),
              confirmButtonText: 'DONE!',
              allowOutsideClick:false
            })
            this.resetPin2(cardNumber);
           } else {
            console.log(data.value);
           Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: (data.message),
            allowOutsideClick:false,
            footer: '<a href>Why do I have this issue?</a>'
           })
        }
          
         })
      }
    })
  }}
    )
  }
  

  viewStatement(){

    const cardNumber1 = localStorage.getItem("cardNumber");
    var cardNumber = Number(cardNumber1)
    let cardDetails = {
      cardNumber
    }
   this.router.navigateByUrl("/debit/showStatement");
    }



 
  
  
  route(){
    this.router.navigateByUrl("contact/debitlist/block1");
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplyDebitComponent } from './apply-debit.component';

describe('ApplyDebitComponent', () => {
  let component: ApplyDebitComponent;
  let fixture: ComponentFixture<ApplyDebitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplyDebitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplyDebitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apply-debit',
  templateUrl: './apply-debit.component.html',
  styleUrls: ['./apply-debit.component.css']
})
export class ApplyDebitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

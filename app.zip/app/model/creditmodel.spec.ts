import { Creditmodel } from './creditmodel';

describe('Creditmodel', () => {
  it('should create an instance', () => {
    expect(new Creditmodel()).toBeTruthy();
  });
});

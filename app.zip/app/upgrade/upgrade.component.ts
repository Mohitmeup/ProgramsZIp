import { Component, OnInit } from '@angular/core';
import { DebitserviceService } from '../service/debitservice.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-upgrade',
  templateUrl: './upgrade.component.html',
  styleUrls: ['./upgrade.component.css']
})
export class UpgradeComponent implements OnInit {
  type: string;
 
  constructor(private debitService: DebitserviceService) { }

  ngOnInit() {
    this.getStatus() ;
  }
  getStatus() {
     const cardNumber1 = localStorage.getItem("card");
     var cardNumber = Number(cardNumber1)
  
    console.log(cardNumber)
    
    let cardDetails = {
      cardNumber
    
    }
    console.log(cardNumber);
    console.log(cardDetails);
   this.debitService.upgrade1(cardDetails).subscribe(
    data => {
      console.log(data);
      console.log(data.value);
      console.log(data.flag);
             if(data.value) {
              console.log(data.value);

              if(data.flag==1)
              data.value='Silver'
              else if(data.flag==2)
              data.value='Gold'
              else if(data.flag==3)
              data.value='Platinum'
   
     this.type=data.value;
     localStorage.setItem("currentType",this.type)
     console.log( this.type)
          }
            else{
              Swal.fire({
                title: 'Oops',
               text: data.message,
                confirmButtonText: 'CANCEL'
              })
            }
           }
   )}



   upgradeGold(){
    const cardNumber1 = localStorage.getItem("card");
    var cardNumber = Number(cardNumber1)
const cardType1=localStorage.getItem("currentType");
console.log(cardType1)
var type="Gold";
if(cardType1=="Silver"){
  
  let cardDetails = {
    cardNumber,
 type
  
  }
  this.debitService.upgrade2(cardDetails).subscribe(
    data => {
      console.log(data);
      console.log(data.value);
  
             if(data.value) {
              console.log(data.value);

              Swal.fire({
                title: 'All done!',
               text: data.message,
                confirmButtonText: 'DONE!'
              })
   
   
 
          }
            
           }
   )

}
else if(cardType1=="Gold"){
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
 html:`You already have a gold card `,
  
   })

}
else if
(cardType1=="Platinum")
{
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
 html:`You can not downgrade to Gold`,
  
   })

}




   }


   upgradeSilver(){
    const cardNumber1 = localStorage.getItem("card");
    var cardNumber = Number(cardNumber1)
const cardType1=localStorage.getItem("currentType");
console.log(cardType1)
var type="Silver";
if(cardType1=="Silver"){
  
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
 html:`You already have a Silver card `,
  
   })

}
else if(cardType1=="Gold"){
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
 html:`You can not downgrade to Silver `,
  
   })

}
else if
(cardType1=="Platinum")
{
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
    html:`You can not downgrade to Silver `,
  
   })

}




   }

   upgradePlatinum(){
    const cardNumber1 = localStorage.getItem("card");
    var cardNumber = Number(cardNumber1)
const cardType1=localStorage.getItem("currentType");
console.log(cardType1)
var type="Platinum";
if(cardType1=="Silver"){
  
  let cardDetails = {
    cardNumber,
 type
  
  }
  this.debitService.upgrade2(cardDetails).subscribe(
    data => {
      console.log(data);
      console.log(data.value);
  
             if(data.value) {
              console.log(data.value);

              Swal.fire({
                title: 'All done!',
               text: data.message,
                confirmButtonText: 'DONE!'
              })
   
   
 
          }
            
           }
   )

}
else if(cardType1=="Gold"){
  let cardDetails = {
    cardNumber,
 type
  
  }
  this.debitService.upgrade2(cardDetails).subscribe(
    data => {
      console.log(data);
      console.log(data.value);
  
             if(data.value) {
              console.log(data.value);

              Swal.fire({
                title: 'All done!',
               text: data.message,
                confirmButtonText: 'DONE!'
              })
   
   
 
          }
            
           }
   )

}
else if
(cardType1=="Platinum")
{
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
 html:`You already have a Platinum card `,
  
   })

}




   }





}

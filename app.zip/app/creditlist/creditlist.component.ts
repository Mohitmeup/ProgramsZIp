import { Component} from '@angular/core';
import { Creditmodel } from '../model/creditmodel';
import { CreditServiceService } from '../service/credit-service.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-creditlist',
  templateUrl: './creditlist.component.html',
  styleUrls: ['./creditlist.component.css']
})
export class CreditlistComponent  {
  bean: Creditmodel[];
  bean1: Creditmodel;
  constructor(private creditService: CreditServiceService, private router:Router) {
  }

  load() {
    console.log("enter1");
    this.creditService.getAll().subscribe(
    
      (data) => {
        console.log("enter"); 
        console.log(data)
       
        this.bean = data;
      
     
    }
      );
}

}

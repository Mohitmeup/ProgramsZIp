import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {DashboardComponent} from './dashboard/dashboard.component';
import {GroupsComponent} from './groups/groups.component';
import {ContactFormComponent} from './contact-form/contact-form.component';
import {SearchContactComponent} from './search-contact/search-contact.component';
import {ContactsListComponent} from './contacts-list/contacts-list.component';
import {DebitlistComponent} from './debitlist/debitlist.component';
import {CarddetailsComponent} from '../app/carddetails/carddetails.component';
import{BlockdebitComponent} from './blockdebit/blockdebit.component'
import{UpgradeComponent} from './upgrade/upgrade.component';
import{ShowCardComponent} from './show-card/show-card.component';
import {DebitStatementComponent} from './debit-statement/debit-statement.component';

import { from } from 'rxjs';

const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'groups',component:GroupsComponent},
  {path:'contacts',component:ContactsListComponent},
  {path:'newContact',component:ContactFormComponent},
  {path:'editContact/:contactId',component:ContactFormComponent},
  {path:'search',component:SearchContactComponent},
  {path:'debit/debitlist',component:DebitlistComponent},
  {path:'carddetails',component:CarddetailsComponent},
  {path: 'block1', component:BlockdebitComponent},
  {path: 'debit/upgrade1', component:UpgradeComponent},
  {path: 'debit/getDetails', component:ShowCardComponent},
  {path:'debit/showStatement',component:DebitStatementComponent},

]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

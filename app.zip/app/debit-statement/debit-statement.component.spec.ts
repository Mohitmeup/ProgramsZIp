import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DebitStatementComponent } from './debit-statement.component';

describe('DebitStatementComponent', () => {
  let component: DebitStatementComponent;
  let fixture: ComponentFixture<DebitStatementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DebitStatementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DebitStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
